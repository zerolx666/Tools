# 0.4.1 验证记录 · 2026-10-30

本轮仅美化显示。生产代码修改限于 GraphCanvas 的绘制、字体测量与卡片尺寸，MapPanel 的边框 / 预览字号，以及 CodePreview 的默认字号；分析器、协议、GraphView、MapService、导航高亮与历史处理保留。版本更新为 0.4.1，旧 0.4.0 安装包保留。

- `test-canvas.ps1`：沿用原有检查，18 项画布与源码预览、21 项导航 / 历史 / 工具栏、65 项文件分组 / 布局 / 精确位置 / 高亮检查通过，共 104 项；未修改测试断言。放大字体后缩小定义卡片留白，保留原有小视口可读布局检查。
- 实际 Swing 画布使用既有真实 Unity 分析结果重新绘制，检查深浅主题、青蓝文件标题、等宽调用代码、行列对齐、选中条、连线、长行省略和中文注释。预览：`build/unity-definition-callers.png`、`build/unity-definition-callers-dark.png`；它们是插件离屏画布，不是 Rider 窗口截图。
- `build.ps1`：前后端编译、35 项既有 Roslyn 语义检查；连同上述界面回归共 139 项。
- `verify-package.ps1`：检查 0.4.1 descriptor、Java 21 字节码、扩展入口及分析器依赖与声明。安装包：`dist/csharp-context-map-0.4.1-plugin.zip`。

未进行实际 Rider 安装验收、不同 DPI 验收或 JetBrains Plugin Verifier。本轮不重新查询 Unity 工程，使用 0.4.0 保存的真实工程结果验证显示；历史工程查询记录如下。

# 0.4.0 验证记录 · 2026-10-30

环境：Windows，Rider 2026.1.3 / RD-261.25134.178，.NET SDK 10.0.301。Java 21 前端、net10.0 本地分析器。修改限于 `Tools/RiderCSharpMap`，未改动游戏资源。

- `build.ps1`：前后端编译、35 项真实 Roslyn 语义检查。新增覆盖 CRLF / LF / CR 归一化、中文与补充平面字符的 UTF-16 坐标、已保存 / 未保存选择、同一行两处调用、定义与使用位置区分、精确 token / 行列、预览上下文、文档 SHA-256 与展开来源。
- `test-unity.ps1`：真实 `Odyssey.sln` 查询。保留 LoadList → Load → 三个读取函数的 6 符号 / 5 关系、按需从 3 到 6 符号、字段自动引用回归。新增默认 Locations 查询 `GameSaver.Save(GameData,int)`，得到 `Game.cs:137` 与 `UISaveCard.cs:71` 两个独立调用文件；逐一验证定义与调用位置的 token、LF 行号和文档指纹。点击 `LoadBinary` 调用处时选择为第 79 行，定义仍为第 144 行。第一次工程加载约 4.7 秒，后续展开约 12ms；样本耗时不代表大型工程性能。
- `test-canvas.ps1` 的 GraphCanvasSmoke：18 项检查，真实 JSON 驱动实际 Swing 画布、预览和鼠标交互。覆盖刷新 / 历史恢复、缩放、普通滚轮、逐符号展开 / 折叠、新列加入关注点稳定、词法着色；新增真实工程中左侧定义、右侧调用文件、箭头方向与精确行选中检查。
- InteractionSmoke：21 项跟随门控、历史、工具栏回归。程序化跳转保持原图，显式编辑器手势恢复跟随，重复符号历史及前进记录保留。
- MapFeatureSmoke：65 项检查。覆盖按文件合框、同名异目录、按行列排序、同一行不同调用保留、重复位置去重、关系合并、单击与 Enter 准确位置回调、根定义保持固定、逐符号展开、递归、布局与概览；新增默认从定义指向调用位置、展开来源、真实调用代码、新编辑器选择覆盖历史行、实际 Swing 预览高亮所在行、源内容 / 指纹 / 行列校验以及 stale 坐标拒绝。
- 上述共 139 项有计数的自动检查，另有真实 Unity 查询与安装包结构检查。
- NavigationHighlight 使用真实实现与 IntelliJ 接口代理验证整行背景、保留语法前景色、替换与清理。SourceLocations 使用实际 Unicode 文本验证偏移、行列和指纹；MapService 的所有源码跳转入口统一使用该结果导航并高亮。
- `verify-package.ps1` 检查单层插件根目录、0.4.0 descriptor、扩展入口、Java 21 字节码、GraphView / GraphCanvas / NavigationHighlight / SourceLocations、分析器、BuildHost、Roslyn 和第三方声明。

已查看真实 Swing 离屏浅色 / 深色图 `build/unity-definition-callers.png` 与 `build/unity-definition-callers-dark.png`：左侧 Save 定义，向右连接两个文件框；选中行显示实际调用代码和行列。它们是当前插件实现驱动的离屏画布，不是 Rider 截图。

尚未完成：实际 Rider 安装与工具窗口生命周期、真实编辑器鼠标 / 键盘事件和整行高亮显示、不同 DPI、其他 Rider 版本、大型解决方案性能、取消底层分析时序、JetBrains Plugin Verifier。本轮未自动安装、替换用户插件或重启 Rider；编译与离屏检查不代表完整 IDE 验收。

运行 `build.ps1`、`test-unity.ps1`、`test-canvas.ps1`、`verify-package.ps1` 可复验。安装包为 `dist/csharp-context-map-0.4.0-plugin.zip`，SHA-256 可通过 `Get-FileHash` 获取。旧版本包保留。
