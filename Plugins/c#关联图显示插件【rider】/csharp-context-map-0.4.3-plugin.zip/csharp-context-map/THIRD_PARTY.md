# Third-party notices

The user-supplied `source-insight-context-relation-2.1.0.vsix`, copyright (c) 2026 onepiece-tools, MIT, was inspected as a feature and interaction reference. No JavaScript, CSS, icons or other program assets from that archive are incorporated into this plugin. Source Insight is a product of its respective owner. This plugin is independent and is not endorsed by Source Insight or JetBrains.

The analyzer redistributes Microsoft.CodeAnalysis and Microsoft.CodeAnalysis.CSharp / Workspaces / MSBuild Workspaces assemblies from the installed .NET SDK, plus their System.Composition / Microsoft.Build.Locator / build host dependencies. These Microsoft components are distributed under the MIT license. .NET and Roslyn third-party notices apply to any transitive dependencies bundled with the SDK tooling. See https://github.com/dotnet/roslyn/blob/main/License.txt, https://github.com/dotnet/roslyn/blob/main/ThirdPartyNotices.rtf, https://github.com/dotnet/runtime/blob/main/LICENSE.TXT, https://github.com/microsoft/MSBuildLocator/blob/main/LICENSE and the license / notices of your installed .NET SDK.

MIT License

Copyright (c) .NET Foundation and Contributors
Copyright (c) Microsoft Corporation. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

The Rider platform and its Gson / annotations APIs are provided by the user's installed IDE and are not copied into this plugin.
