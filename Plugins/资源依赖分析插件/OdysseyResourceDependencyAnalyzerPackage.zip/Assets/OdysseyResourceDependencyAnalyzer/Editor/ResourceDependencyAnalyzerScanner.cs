using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Odyssey.ResourceDependencyAnalyzer
{
    internal sealed class ResourceAnalyzerScanSession
    {
        private readonly ResourceAnalyzerDatabase database = new ResourceAnalyzerDatabase();
        private readonly List<string> paths = new List<string>();
        private readonly bool includePackages;
        private readonly bool computeHashes;
        private readonly OdysseyAddressablesBridge addressables;
        private int phase;
        private int index;
        private bool finalized;

        public ResourceAnalyzerScanSession(bool includePackages, bool computeHashes)
        {
            this.includePackages = includePackages;
            this.computeHashes = computeHashes;
            addressables = OdysseyAddressablesBridge.Create();
            database.IncludePackages = includePackages;
            database.ComputeHashes = computeHashes;
            database.AddressablesAvailable = addressables.IsAvailable;
            CollectPaths();
        }

        public ResourceAnalyzerDatabase Database
        {
            get { return database; }
        }

        public bool IsComplete
        {
            get { return finalized; }
        }

        public string PhaseLabel
        {
            get
            {
                switch (phase)
                {
                    case 0: return "建立资源索引";
                    case 1: return "读取直接依赖";
                    case 2: return "计算入口可达性与重复项";
                    default: return "完成";
                }
            }
        }

        public float Progress
        {
            get
            {
                var total = Math.Max(1, paths.Count * 2);
                var completed = phase == 0 ? index : paths.Count + index;
                if (phase >= 2) return 1f;
                return Mathf.Clamp01(completed / (float)total);
            }
        }

        public int AssetCount
        {
            get { return paths.Count; }
        }

        public bool Process(int budget)
        {
            if (finalized) return true;
            budget = Math.Max(1, budget);

            while (budget-- > 0 && !finalized)
            {
                if (phase == 0)
                {
                    ProcessAssetPath(paths[index++]);
                    if (index >= paths.Count)
                    {
                        phase = database.Assets.Count == 0 ? 2 : 1;
                        index = 0;
                    }
                }
                else if (phase == 1)
                {
                    ProcessDependencies(database.Assets[index++]);
                    if (index >= database.Assets.Count)
                    {
                        phase = 2;
                        index = 0;
                    }
                }
                else
                {
                    FinalizeDatabase();
                }
            }

            return finalized;
        }

        private void CollectPaths()
        {
            var allPaths = AssetDatabase.GetAllAssetPaths();
            for (var i = 0; i < allPaths.Length; i++)
            {
                var path = ResourceAnalyzerUtilities.NormalizePath(allPaths[i]);
                if (!ResourceAnalyzerUtilities.IsProjectAssetPath(path, includePackages)) continue;
                if (ResourceAnalyzerUtilities.IsFolder(path)) continue;
                if (path.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)) continue;
                paths.Add(path);
            }
            paths.Sort(StringComparer.OrdinalIgnoreCase);
            if (paths.Count == 0)
            {
                phase = 2;
            }
        }

        private void ProcessAssetPath(string path)
        {
            try
            {
                var info = new ResourceAssetInfo
                {
                    path = path,
                    guid = AssetDatabase.AssetPathToGUID(path),
                    typeName = GetTypeName(path),
                    sizeBytes = ResourceAnalyzerUtilities.GetFileSize(path),
                    isInResources = ResourceAnalyzerUtilities.IsUnderFolder(path, "Resources"),
                    isInStreamingAssets = ResourceAnalyzerUtilities.IsUnderFolder(path, "StreamingAssets"),
                    isEditorOnly = ResourceAnalyzerUtilities.IsEditorOnly(path)
                };

                if (computeHashes)
                {
                    info.sha256 = ResourceAnalyzerUtilities.ComputeSha256(path);
                }

                if (addressables.TryGetEntry(info.guid, out var address, out var group, out var labels))
                {
                    info.isAddressable = true;
                    info.addressableAddress = address;
                    info.addressableGroup = group;
                    info.addressableLabels = labels;
                }

                database.Assets.Add(info);
                if (!string.IsNullOrEmpty(path))
                {
                    database.ByPath[path] = info;
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[Odyssey Resource Dependency Analyzer] Failed to inspect " + path + ": " + exception.Message);
            }
        }

        private void ProcessDependencies(ResourceAssetInfo info)
        {
            if (info == null) return;
            try
            {
                var dependencies = AssetDatabase.GetDependencies(info.path, false);
                for (var i = 0; i < dependencies.Length; i++)
                {
                    var dependency = ResourceAnalyzerUtilities.NormalizePath(dependencies[i]);
                    if (string.IsNullOrEmpty(dependency) || string.Equals(dependency, info.path, StringComparison.OrdinalIgnoreCase)) continue;
                    if (!info.dependencies.Contains(dependency)) info.dependencies.Add(dependency);

                    var referenced = database.Get(dependency);
                    if (referenced != null && !referenced.references.Contains(info.path))
                    {
                        referenced.references.Add(info.path);
                    }
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[Odyssey Resource Dependency Analyzer] Failed to read dependencies for " + info.path + ": " + exception.Message);
            }
        }

        private void FinalizeDatabase()
        {
            if (finalized) return;

            MarkRoots();
            MarkReachableAssets();
            MarkDuplicateGroups();
            database.Assets.Sort(delegate(ResourceAssetInfo left, ResourceAssetInfo right)
            {
                return string.Compare(left.path, right.path, StringComparison.OrdinalIgnoreCase);
            });
            database.HasScan = true;
            database.LastScanUtc = DateTime.UtcNow;
            finalized = true;
            phase = 3;
        }

        private void MarkRoots()
        {
            var enabledBuildScenes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var scenes = EditorBuildSettings.scenes;
            for (var i = 0; i < scenes.Length; i++)
            {
                if (scenes[i].enabled && !string.IsNullOrEmpty(scenes[i].path))
                {
                    enabledBuildScenes.Add(ResourceAnalyzerUtilities.NormalizePath(scenes[i].path));
                }
            }

            for (var i = 0; i < database.Assets.Count; i++)
            {
                var info = database.Assets[i];
                if (enabledBuildScenes.Contains(info.path))
                {
                    info.isBuildScene = true;
                    AddRootReason(info, "Build Settings 场景");
                }
                if (info.isAddressable) AddRootReason(info, "Addressables");
                if (info.isInResources) AddRootReason(info, "Resources");
                if (info.isInStreamingAssets) AddRootReason(info, "StreamingAssets");
                info.isRoot = info.rootReasons.Count > 0;
            }
        }

        private void MarkReachableAssets()
        {
            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var queue = new Queue<ResourceAssetInfo>();

            for (var i = 0; i < database.Assets.Count; i++)
            {
                var info = database.Assets[i];
                if (info.isRoot && visited.Add(info.path)) queue.Enqueue(info);
            }

            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                current.isReachableFromEntryPoint = true;
                for (var i = 0; i < current.dependencies.Count; i++)
                {
                    var dependency = database.Get(current.dependencies[i]);
                    if (dependency != null && visited.Add(dependency.path)) queue.Enqueue(dependency);
                }
            }

            for (var i = 0; i < database.Assets.Count; i++)
            {
                var info = database.Assets[i];
                info.isSuspectedUnused = !info.isReachableFromEntryPoint
                    && !info.isRoot
                    && !info.isEditorOnly
                    && ResourceAnalyzerUtilities.IsLikelyRuntimeAsset(info.path);
            }
        }

        private void MarkDuplicateGroups()
        {
            if (!computeHashes) return;
            var groups = new Dictionary<string, List<ResourceAssetInfo>>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < database.Assets.Count; i++)
            {
                var info = database.Assets[i];
                if (string.IsNullOrEmpty(info.sha256)) continue;
                if (!groups.TryGetValue(info.sha256, out var group))
                {
                    group = new List<ResourceAssetInfo>();
                    groups.Add(info.sha256, group);
                }
                group.Add(info);
            }

            foreach (var pair in groups)
            {
                if (pair.Value.Count < 2) continue;
                for (var i = 0; i < pair.Value.Count; i++) pair.Value[i].duplicateCount = pair.Value.Count;
            }
        }

        private static void AddRootReason(ResourceAssetInfo info, string reason)
        {
            if (!info.rootReasons.Contains(reason)) info.rootReasons.Add(reason);
        }

        private static string GetTypeName(string path)
        {
            try
            {
                var type = AssetDatabase.GetMainAssetTypeAtPath(path);
                return type == null ? string.Empty : type.FullName;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}


