using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace Odyssey.ResourceDependencyAnalyzer
{
    [Serializable]
    internal sealed class ResourceAssetInfo
    {
        public string path;
        public string guid;
        public string typeName;
        public long sizeBytes;
        public string sha256;
        public List<string> dependencies = new List<string>();
        public List<string> references = new List<string>();
        public List<string> rootReasons = new List<string>();
        public string addressableAddress;
        public string addressableGroup;
        public List<string> addressableLabels = new List<string>();
        public bool isAddressable;
        public bool isBuildScene;
        public bool isInResources;
        public bool isInStreamingAssets;
        public bool isEditorOnly;
        public bool isRoot;
        public bool isReachableFromEntryPoint;
        public bool isSuspectedUnused;
        public int duplicateCount;

        public string DisplayType
        {
            get
            {
                if (string.IsNullOrEmpty(typeName))
                {
                    return "Unknown";
                }

                var lastDot = typeName.LastIndexOf('.');
                return lastDot >= 0 && lastDot < typeName.Length - 1
                    ? typeName.Substring(lastDot + 1)
                    : typeName;
            }
        }

        public string DisplaySize
        {
            get { return ResourceAnalyzerUtilities.FormatBytes(sizeBytes); }
        }
    }

    [Serializable]
    internal sealed class ResourceAnalyzerReport
    {
        public string toolVersion;
        public string unityVersion;
        public string generatedAtUtc;
        public string projectPath;
        public bool includePackages;
        public bool computeHashes;
        public int assetCount;
        public int addressableCount;
        public int reachableCount;
        public int suspectedUnusedCount;
        public int duplicateAssetCount;
        public List<ResourceAssetInfo> assets = new List<ResourceAssetInfo>();
    }

    internal sealed class ResourceAnalyzerDatabase
    {
        public readonly List<ResourceAssetInfo> Assets = new List<ResourceAssetInfo>();
        public readonly Dictionary<string, ResourceAssetInfo> ByPath = new Dictionary<string, ResourceAssetInfo>(StringComparer.OrdinalIgnoreCase);
        public bool HasScan;
        public bool AddressablesAvailable;
        public bool IncludePackages;
        public bool ComputeHashes;
        public DateTime LastScanUtc;

        public void Clear()
        {
            Assets.Clear();
            ByPath.Clear();
            HasScan = false;
            AddressablesAvailable = false;
            IncludePackages = false;
            ComputeHashes = false;
            LastScanUtc = default(DateTime);
        }

        public ResourceAssetInfo Get(string path)
        {
            ResourceAssetInfo info;
            return !string.IsNullOrEmpty(path) && ByPath.TryGetValue(path, out info) ? info : null;
        }

        public ResourceAnalyzerReport ToReport()
        {
            var report = new ResourceAnalyzerReport
            {
                toolVersion = ResourceAnalyzerUtilities.ToolVersion,
                unityVersion = Application.unityVersion,
                generatedAtUtc = LastScanUtc == default(DateTime) ? string.Empty : LastScanUtc.ToString("o"),
                projectPath = ResourceAnalyzerUtilities.ProjectRoot,
                includePackages = IncludePackages,
                computeHashes = ComputeHashes,
                assets = new List<ResourceAssetInfo>(Assets)
            };

            var addressableCount = 0;
            var reachableCount = 0;
            var unusedCount = 0;
            var duplicateAssetCount = 0;
            for (var i = 0; i < Assets.Count; i++)
            {
                var asset = Assets[i];
                if (asset.isAddressable) addressableCount++;
                if (asset.isReachableFromEntryPoint) reachableCount++;
                if (asset.isSuspectedUnused) unusedCount++;
                if (asset.duplicateCount > 1) duplicateAssetCount++;
            }

            report.assetCount = Assets.Count;
            report.addressableCount = addressableCount;
            report.reachableCount = reachableCount;
            report.suspectedUnusedCount = unusedCount;
            report.duplicateAssetCount = duplicateAssetCount;
            return report;
        }
    }

    /// <summary>
    /// Optional Addressables editor integration. Reflection keeps the analyzer usable in projects
    /// that do not install Addressables and avoids a hard assembly reference from this package.
    /// </summary>
    internal sealed class OdysseyAddressablesBridge
    {
        private object settings;
        private MethodInfo findAssetEntry;
        private bool initialized;

        public bool IsAvailable { get; private set; }

        public static OdysseyAddressablesBridge Create()
        {
            var bridge = new OdysseyAddressablesBridge();
            bridge.Initialize();
            return bridge;
        }

        public bool TryGetEntry(string guid, out string address, out string group, out List<string> labels)
        {
            address = null;
            group = null;
            labels = new List<string>();

            if (!initialized || !IsAvailable || string.IsNullOrEmpty(guid))
            {
                return false;
            }

            try
            {
                var parameters = findAssetEntry.GetParameters();
                var arguments = parameters.Length == 1
                    ? new object[] { guid }
                    : new object[] { guid, false };
                var entry = findAssetEntry.Invoke(settings, arguments);
                if (entry == null)
                {
                    return false;
                }

                address = ReadString(entry, "address");
                var parentGroup = ReadMember(entry, "parentGroup");
                group = ReadString(parentGroup, "Name");
                if (string.IsNullOrEmpty(group))
                {
                    group = ReadString(parentGroup, "name");
                }

                var rawLabels = ReadMember(entry, "labels") as IEnumerable;
                if (rawLabels != null)
                {
                    foreach (var label in rawLabels)
                    {
                        if (label != null)
                        {
                            labels.Add(label.ToString());
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {
                // Addressables editor APIs vary between package versions. The core analyzer remains usable.
                return false;
            }
        }

        private void Initialize()
        {
            if (initialized)
            {
                return;
            }

            initialized = true;
            try
            {
                var settingsType = FindType("UnityEditor.AddressableAssets.Settings.AddressableAssetSettingsDefaultObject");
                if (settingsType == null)
                {
                    return;
                }

                settings = ReadStaticMember(settingsType, "Settings");
                if (settings == null)
                {
                    return;
                }

                findAssetEntry = FindMethod(settings.GetType(), "FindAssetEntry", typeof(string));
                IsAvailable = findAssetEntry != null;
            }
            catch (Exception)
            {
                IsAvailable = false;
            }
        }

        private static Type FindType(string fullName)
        {
            var direct = Type.GetType(fullName + ", Unity.Addressables.Editor");
            if (direct != null)
            {
                return direct;
            }

            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    var type = assembly.GetType(fullName, false);
                    if (type != null)
                    {
                        return type;
                    }
                }
                catch (Exception)
                {
                    // Some editor assemblies can throw while exposing type metadata.
                }
            }

            return null;
        }

        private static MethodInfo FindMethod(Type type, string methodName, Type parameterType)
        {
            if (type == null) return null;
            var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            for (var i = 0; i < methods.Length; i++)
            {
                var method = methods[i];
                if (method.Name != methodName) continue;
                var parameters = method.GetParameters();
                if (parameters.Length == 1 && parameters[0].ParameterType == parameterType)
                {
                    return method;
                }
                if (parameters.Length == 2
                    && parameters[0].ParameterType == parameterType
                    && parameters[1].ParameterType == typeof(bool))
                {
                    return method;
                }
            }
            return null;
        }

        private static object ReadStaticMember(Type type, string memberName)
        {
            var property = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (property != null) return property.GetValue(null, null);
            var field = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            return field == null ? null : field.GetValue(null);
        }

        private static object ReadMember(object instance, string memberName)
        {
            if (instance == null) return null;
            var type = instance.GetType();
            var property = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (property != null) return property.GetValue(instance, null);
            var field = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            return field == null ? null : field.GetValue(instance);
        }

        private static string ReadString(object instance, string memberName)
        {
            var value = ReadMember(instance, memberName);
            return value == null ? null : value.ToString();
        }
    }

    internal static class ResourceAnalyzerUtilities
    {
        public const string ToolVersion = "1.0.0";

        public static string ProjectRoot
        {
            get
            {
                var directory = Directory.GetParent(Application.dataPath);
                return directory == null ? string.Empty : directory.FullName;
            }
        }

        public static string NormalizePath(string path)
        {
            return string.IsNullOrEmpty(path) ? string.Empty : path.Replace('\\', '/');
        }

        public static bool IsProjectAssetPath(string path, bool includePackages)
        {
            path = NormalizePath(path);
            return path.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                || (includePackages && path.StartsWith("Packages/", StringComparison.OrdinalIgnoreCase));
        }

        public static bool IsFolder(string path)
        {
            try
            {
                return AssetDatabase.IsValidFolder(path);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool IsUnderFolder(string path, string folderName)
        {
            path = NormalizePath(path);
            var parts = path.Split('/');
            for (var i = 0; i < parts.Length - 1; i++)
            {
                if (string.Equals(parts[i], folderName, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        public static bool IsEditorOnly(string path)
        {
            return IsUnderFolder(path, "Editor") || IsUnderFolder(path, "Gizmos");
        }

        public static bool IsLikelyRuntimeAsset(string path)
        {
            var extension = Path.GetExtension(path).ToLowerInvariant();
            switch (extension)
            {
                case ".cs":
                case ".js":
                case ".dll":
                case ".asmdef":
                case ".asmref":
                case ".rsp":
                case ".hlsl":
                case ".cginc":
                case ".shader":
                case ".compute":
                case ".uss":
                case ".uxml":
                case ".md":
                case ".txt":
                    return false;
                default:
                    return true;
            }
        }

        public static string ToAbsolutePath(string projectRelativePath)
        {
            if (string.IsNullOrEmpty(projectRelativePath)) return string.Empty;
            return Path.Combine(ProjectRoot, projectRelativePath.Replace('/', Path.DirectorySeparatorChar));
        }

        public static long GetFileSize(string projectRelativePath)
        {
            try
            {
                var absolutePath = ToAbsolutePath(projectRelativePath);
                return File.Exists(absolutePath) ? new FileInfo(absolutePath).Length : 0L;
            }
            catch (Exception)
            {
                return 0L;
            }
        }

        public static string ComputeSha256(string projectRelativePath)
        {
            try
            {
                var absolutePath = ToAbsolutePath(projectRelativePath);
                if (!File.Exists(absolutePath)) return string.Empty;
                using (var sha = System.Security.Cryptography.SHA256.Create())
                using (var stream = new FileStream(absolutePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    var hash = sha.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", string.Empty).ToLowerInvariant();
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string Csv(string value)
        {
            if (value == null) return "\"\"";
            return "\"" + value.Replace("\"", "\"\"").Replace("\r", " ").Replace("\n", " ") + "\"";
        }

        public static string JoinValues(List<string> values)
        {
            if (values == null || values.Count == 0) return string.Empty;
            return string.Join("; ", values.ToArray());
        }

        public static string FormatBytes(long bytes)
        {
            if (bytes < 1024L) return bytes + " B";
            if (bytes < 1024L * 1024L) return (bytes / 1024d).ToString("0.0") + " KB";
            if (bytes < 1024L * 1024L * 1024L) return (bytes / (1024d * 1024d)).ToString("0.0") + " MB";
            return (bytes / (1024d * 1024d * 1024d)).ToString("0.00") + " GB";
        }
    }
}

