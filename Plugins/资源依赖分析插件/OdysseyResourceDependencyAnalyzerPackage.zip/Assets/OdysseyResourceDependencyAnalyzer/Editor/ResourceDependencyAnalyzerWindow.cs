using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Odyssey.ResourceDependencyAnalyzer
{
    internal enum ResourceAnalyzerFilter
    {
        All,
        SuspectedUnused,
        Addressables,
        Duplicates,
        BuildScenes
    }

    internal sealed class ResourceDependencyAnalyzerWindow : EditorWindow
    {
        private static readonly List<ResourceDependencyAnalyzerWindow> OpenWindows = new List<ResourceDependencyAnalyzerWindow>();

        private ResourceAnalyzerDatabase database = new ResourceAnalyzerDatabase();
        private ResourceAnalyzerScanSession scan;
        private ResourceAssetInfo selectedAsset;
        private Vector2 assetListScroll;
        private Vector2 detailScroll;
        private string searchText = string.Empty;
        private ResourceAnalyzerFilter filter;
        private bool includePackages;
        private bool computeHashes = true;
        private bool scanStale;

        [MenuItem("Tools/Odyssey/Resource Dependency Analyzer", priority = 1200)]
        public static void Open()
        {
            var window = GetWindow<ResourceDependencyAnalyzerWindow>();
            window.titleContent = new GUIContent("Resource Dependencies");
            window.minSize = new Vector2(900f, 560f);
            window.Show();
        }

        public static void MarkStale()
        {
            for (var i = 0; i < OpenWindows.Count; i++)
            {
                OpenWindows[i].scanStale = true;
                OpenWindows[i].Repaint();
            }
        }

        private void OnEnable()
        {
            if (!OpenWindows.Contains(this)) OpenWindows.Add(this);
            EditorApplication.update += OnEditorUpdate;
            titleContent = new GUIContent("Resource Dependencies");
        }

        private void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
            OpenWindows.Remove(this);
            scan = null;
        }

        private void OnSelectionChange()
        {
            if (!database.HasScan || Selection.activeObject == null) return;
            var path = ResourceAnalyzerUtilities.NormalizePath(AssetDatabase.GetAssetPath(Selection.activeObject));
            var info = database.Get(path);
            if (info != null)
            {
                selectedAsset = info;
                Repaint();
            }
        }

        private void OnEditorUpdate()
        {
            if (scan == null) return;

            try
            {
                if (scan.Process(12))
                {
                    database = scan.Database;
                    scan = null;
                    selectedAsset = null;
                    scanStale = false;
                    Repaint();
                }
                else
                {
                    Repaint();
                }
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                scan = null;
                Repaint();
            }
        }

        private void OnGUI()
        {
            DrawToolbar();
            if (scan != null)
            {
                DrawScanProgress();
                return;
            }

            if (!database.HasScan)
            {
                DrawEmptyState();
                return;
            }

            DrawSummary();
            if (scanStale)
            {
                EditorGUILayout.HelpBox("项目资源已发生变化，当前结果可能已过期。建议重新扫描。", MessageType.Warning);
            }
            if (!database.AddressablesAvailable)
            {
                EditorGUILayout.HelpBox("未检测到 Addressables 编辑器 API。核心依赖分析仍可用；安装或启用 Addressables 后重新扫描即可读取条目、地址、分组和标签。", MessageType.Info);
            }
            DrawResults();
        }

        private void DrawToolbar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUI.enabled = scan == null;
                if (GUILayout.Button("扫描项目", EditorStyles.toolbarButton, GUILayout.Width(76f))) StartScan();
                if (GUILayout.Button("导出 JSON", EditorStyles.toolbarButton, GUILayout.Width(76f))) ExportJson();
                if (GUILayout.Button("导出 CSV", EditorStyles.toolbarButton, GUILayout.Width(76f))) ExportCsv();
                if (GUILayout.Button("清空", EditorStyles.toolbarButton, GUILayout.Width(52f)))
                {
                    database.Clear();
                    selectedAsset = null;
                    scanStale = false;
                }
                GUILayout.Space(8f);
                includePackages = GUILayout.Toggle(includePackages, "包含 Packages", EditorStyles.toolbarButton);
                computeHashes = GUILayout.Toggle(computeHashes, "计算 SHA-256", EditorStyles.toolbarButton);
                GUILayout.FlexibleSpace();
                GUI.enabled = true;
                if (scan != null)
                {
                    if (GUILayout.Button("取消扫描", EditorStyles.toolbarButton, GUILayout.Width(76f)))
                    {
                        scan = null;
                        Repaint();
                    }
                }
            }
        }

        private void DrawScanProgress()
        {
            GUILayout.Space(18f);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("正在扫描项目资源", EditorStyles.boldLabel);
                EditorGUILayout.LabelField(scan.PhaseLabel + "（" + scan.AssetCount + " 个候选资源）");
                var rect = GUILayoutUtility.GetRect(1f, 22f);
                EditorGUI.ProgressBar(rect, scan.Progress, (scan.Progress * 100f).ToString("0") + "%");
                EditorGUILayout.HelpBox("扫描期间不会修改资源。计算哈希可能需要一些时间，大型项目可取消后关闭“计算 SHA-256”再扫描。", MessageType.Info);
            }
        }

        private void DrawEmptyState()
        {
            GUILayout.Space(24f);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                GUILayout.Label("Odyssey Resource Dependency Analyzer", EditorStyles.boldLabel);
                GUILayout.Space(6f);
                EditorGUILayout.LabelField("扫描项目后可查看依赖、反向引用、Addressables 可达性、重复资源和疑似未使用资源。", EditorStyles.wordWrappedLabel);
                GUILayout.Space(10f);
                if (GUILayout.Button("开始扫描", GUILayout.Height(32f))) StartScan();
                GUILayout.Space(6f);
                EditorGUILayout.HelpBox("“疑似未使用”只代表静态入口不可达。Resources.Load、反射、字符串路径、自定义 AssetBundle 和远程下载可能无法被静态分析识别。", MessageType.Warning);
            }
        }

        private void DrawSummary()
        {
            var report = database.ToReport();
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawMetric("资源", report.assetCount.ToString());
                DrawMetric("可达", report.reachableCount.ToString());
                DrawMetric("Addressables", report.addressableCount.ToString());
                DrawMetric("疑似未使用", report.suspectedUnusedCount.ToString());
                DrawMetric("重复资源", report.duplicateAssetCount.ToString());
            }
            EditorGUILayout.LabelField("上次扫描：" + (database.LastScanUtc == default(DateTime) ? "-" : database.LastScanUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss")), EditorStyles.miniLabel);
        }

        private static void DrawMetric(string label, string value)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.MinWidth(120f)))
            {
                EditorGUILayout.LabelField(label, EditorStyles.miniLabel);
                EditorGUILayout.LabelField(value, EditorStyles.boldLabel);
            }
        }

        private void DrawResults()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                filter = (ResourceAnalyzerFilter)GUILayout.Toolbar((int)filter, new[] { "全部", "疑似未使用", "Addressables", "重复", "构建场景" }, EditorStyles.toolbarButton);
                GUILayout.FlexibleSpace();
                searchText = GUILayout.TextField(searchText, GUI.skin.FindStyle("ToolbarSearchTextField") ?? EditorStyles.toolbarTextField, GUILayout.Width(260f));
                if (GUILayout.Button("×", EditorStyles.toolbarButton, GUILayout.Width(22f))) searchText = string.Empty;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                DrawAssetList();
                DrawAssetDetails();
            }
        }

        private void DrawAssetList()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * 0.58f)))
            {
                assetListScroll = EditorGUILayout.BeginScrollView(assetListScroll);
                var visibleCount = 0;
                for (var i = 0; i < database.Assets.Count; i++)
                {
                    var info = database.Assets[i];
                    if (!MatchesFilter(info) || !MatchesSearch(info)) continue;
                    visibleCount++;
                    DrawAssetRow(info);
                }
                if (visibleCount == 0)
                {
                    EditorGUILayout.HelpBox("没有匹配的资源。", MessageType.Info);
                }
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawAssetRow(ResourceAssetInfo info)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                var label = info.path + "\n" + info.DisplayType + "  ·  " + info.DisplaySize;
                if (GUILayout.Button(label, EditorStyles.label, GUILayout.MinHeight(36f)))
                {
                    selectedAsset = info;
                    Repaint();
                }
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(92f)))
                {
                    if (info.isSuspectedUnused) GUILayout.Label("疑似未使用", EditorStyles.miniLabel);
                    if (info.isAddressable) GUILayout.Label("Addressable", EditorStyles.miniLabel);
                    if (info.duplicateCount > 1) GUILayout.Label("重复 ×" + info.duplicateCount, EditorStyles.miniLabel);
                }
            }
        }

        private void DrawAssetDetails()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                detailScroll = EditorGUILayout.BeginScrollView(detailScroll);
                if (selectedAsset == null)
                {
                    EditorGUILayout.HelpBox("从左侧选择一个资源查看详情。", MessageType.Info);
                    EditorGUILayout.EndScrollView();
                    return;
                }

                EditorGUILayout.LabelField("资源详情", EditorStyles.boldLabel);
                EditorGUILayout.SelectableLabel(selectedAsset.path, EditorStyles.textField, GUILayout.Height(34f));
                if (GUILayout.Button("在 Project 中定位")) PingAsset(selectedAsset.path);
                EditorGUILayout.LabelField("类型", selectedAsset.DisplayType);
                EditorGUILayout.LabelField("大小", selectedAsset.DisplaySize);
                EditorGUILayout.LabelField("GUID", string.IsNullOrEmpty(selectedAsset.guid) ? "-" : selectedAsset.guid);
                if (!string.IsNullOrEmpty(selectedAsset.sha256)) EditorGUILayout.SelectableLabel("SHA-256\n" + selectedAsset.sha256, EditorStyles.textField, GUILayout.Height(44f));
                if (selectedAsset.isAddressable)
                {
                    EditorGUILayout.LabelField("Addressables 地址", string.IsNullOrEmpty(selectedAsset.addressableAddress) ? "-" : selectedAsset.addressableAddress);
                    EditorGUILayout.LabelField("分组", string.IsNullOrEmpty(selectedAsset.addressableGroup) ? "-" : selectedAsset.addressableGroup);
                    EditorGUILayout.LabelField("标签", ResourceAnalyzerUtilities.JoinValues(selectedAsset.addressableLabels));
                }
                if (selectedAsset.rootReasons.Count > 0) EditorGUILayout.LabelField("入口", ResourceAnalyzerUtilities.JoinValues(selectedAsset.rootReasons));
                if (selectedAsset.isReachableFromEntryPoint) EditorGUILayout.LabelField("可达性", "从入口可达");
                if (selectedAsset.isSuspectedUnused) EditorGUILayout.HelpBox("这是静态分析得到的疑似未使用候选，请结合运行时加载逻辑人工确认。", MessageType.Warning);

                DrawRelatedPaths("直接依赖（" + selectedAsset.dependencies.Count + "）", selectedAsset.dependencies);
                DrawRelatedPaths("反向引用（" + selectedAsset.references.Count + "）", selectedAsset.references);
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawRelatedPaths(string title, List<string> paths)
        {
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
            if (paths == null || paths.Count == 0)
            {
                EditorGUILayout.LabelField("无", EditorStyles.miniLabel);
                return;
            }

            var limit = Math.Min(paths.Count, 300);
            for (var i = 0; i < limit; i++)
            {
                var path = paths[i];
                if (GUILayout.Button(path, EditorStyles.linkLabel)) SelectAssetPath(path);
            }
            if (paths.Count > limit) EditorGUILayout.LabelField("还有 " + (paths.Count - limit) + " 项未显示", EditorStyles.miniLabel);
        }

        private bool MatchesFilter(ResourceAssetInfo info)
        {
            switch (filter)
            {
                case ResourceAnalyzerFilter.SuspectedUnused: return info.isSuspectedUnused;
                case ResourceAnalyzerFilter.Addressables: return info.isAddressable;
                case ResourceAnalyzerFilter.Duplicates: return info.duplicateCount > 1;
                case ResourceAnalyzerFilter.BuildScenes: return info.isBuildScene;
                default: return true;
            }
        }

        private bool MatchesSearch(ResourceAssetInfo info)
        {
            if (string.IsNullOrEmpty(searchText)) return true;
            var comparison = StringComparison.OrdinalIgnoreCase;
            return (info.path ?? string.Empty).IndexOf(searchText, comparison) >= 0
                || (info.typeName ?? string.Empty).IndexOf(searchText, comparison) >= 0
                || (info.addressableAddress ?? string.Empty).IndexOf(searchText, comparison) >= 0
                || (info.addressableGroup ?? string.Empty).IndexOf(searchText, comparison) >= 0;
        }

        private void StartScan()
        {
            if (scan != null) return;
            database.Clear();
            selectedAsset = null;
            scanStale = false;
            scan = new ResourceAnalyzerScanSession(includePackages, computeHashes);
            Repaint();
        }

        private void SelectAssetPath(string path)
        {
            var info = database.Get(path);
            if (info != null)
            {
                selectedAsset = info;
                Repaint();
            }
            PingAsset(path);
        }

        private static void PingAsset(string path)
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            if (asset != null)
            {
                Selection.activeObject = asset;
                EditorGUIUtility.PingObject(asset);
                EditorUtility.FocusProjectWindow();
            }
        }

        private void ExportJson()
        {
            if (!database.HasScan)
            {
                EditorUtility.DisplayDialog("无法导出", "请先完成一次扫描。", "确定");
                return;
            }
            var filePath = EditorUtility.SaveFilePanel("导出资源依赖 JSON", ResourceAnalyzerUtilities.ProjectRoot, "resource-dependency-report.json", "json");
            if (string.IsNullOrEmpty(filePath)) return;
            File.WriteAllText(filePath, JsonUtility.ToJson(database.ToReport(), true), new UTF8Encoding(false));
            EditorUtility.RevealInFinder(filePath);
        }

        private void ExportCsv()
        {
            if (!database.HasScan)
            {
                EditorUtility.DisplayDialog("无法导出", "请先完成一次扫描。", "确定");
                return;
            }
            var filePath = EditorUtility.SaveFilePanel("导出资源依赖 CSV", ResourceAnalyzerUtilities.ProjectRoot, "resource-dependency-report.csv", "csv");
            if (string.IsNullOrEmpty(filePath)) return;
            var builder = new StringBuilder();
            builder.AppendLine("Path,GUID,Type,SizeBytes,SHA256,Addressable,Address,Group,Labels,RootReasons,Reachable,SuspectedUnused,DuplicateCount,Dependencies,References");
            for (var i = 0; i < database.Assets.Count; i++)
            {
                var info = database.Assets[i];
                builder.Append(ResourceAnalyzerUtilities.Csv(info.path)).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(info.guid)).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(info.typeName)).Append(',')
                    .Append(info.sizeBytes).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(info.sha256)).Append(',')
                    .Append(info.isAddressable ? "true" : "false").Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(info.addressableAddress)).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(info.addressableGroup)).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(ResourceAnalyzerUtilities.JoinValues(info.addressableLabels))).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(ResourceAnalyzerUtilities.JoinValues(info.rootReasons))).Append(',')
                    .Append(info.isReachableFromEntryPoint ? "true" : "false").Append(',')
                    .Append(info.isSuspectedUnused ? "true" : "false").Append(',')
                    .Append(info.duplicateCount).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(ResourceAnalyzerUtilities.JoinValues(info.dependencies))).Append(',')
                    .Append(ResourceAnalyzerUtilities.Csv(ResourceAnalyzerUtilities.JoinValues(info.references))).AppendLine();
            }
            File.WriteAllText(filePath, builder.ToString(), new UTF8Encoding(true));
            EditorUtility.RevealInFinder(filePath);
        }
    }
}



