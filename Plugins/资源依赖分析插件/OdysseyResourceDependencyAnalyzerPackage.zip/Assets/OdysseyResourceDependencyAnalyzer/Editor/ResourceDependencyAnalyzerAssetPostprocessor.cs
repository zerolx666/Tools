using UnityEditor;

namespace Odyssey.ResourceDependencyAnalyzer
{
    internal sealed class ResourceDependencyAnalyzerAssetPostprocessor : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets,
            string[] deletedAssets,
            string[] movedAssets,
            string[] movedFromAssetPaths)
        {
            if ((importedAssets != null && importedAssets.Length > 0)
                || (deletedAssets != null && deletedAssets.Length > 0)
                || (movedAssets != null && movedAssets.Length > 0))
            {
                ResourceDependencyAnalyzerWindow.MarkStale();
            }
        }
    }
}
