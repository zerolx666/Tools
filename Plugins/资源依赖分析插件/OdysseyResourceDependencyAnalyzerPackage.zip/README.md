# Odyssey Resource Dependency Analyzer

面向 Unity 2023.2 的编辑器资源依赖分析工具。插件只在 Editor 中运行，不会修改、移动或删除项目资源。

## 安装

1. 将压缩包中的 `Assets/OdysseyResourceDependencyAnalyzer` 文件夹复制到 Unity 项目的 `Assets` 目录。
2. 返回 Unity，等待编译完成。
3. 打开菜单：`Tools > Odyssey > Resource Dependency Analyzer`。

## 功能

- 扫描 Assets（可选包含 Packages）中的可导入资源。
- 展示直接依赖和反向引用。
- 以 Build Settings 场景、Addressables 条目、Resources 和 StreamingAssets 为入口计算可达资源。
- 标记“疑似未使用”资源；这是静态分析候选，不代表可以直接删除。
- 按文件 SHA-256 查找内容完全相同的重复资源。
- 支持 CSV / JSON 报告导出。
- Addressables 通过反射访问编辑器 API，不对项目增加硬引用；未安装 Addressables 时核心功能仍可用。
- 资源导入、删除或移动后会提示扫描结果已过期。

## 重要说明

静态依赖无法可靠识别运行时字符串加载、反射、远程下载、自定义 AssetBundle 流程或脚本中的动态路径。因此请把“疑似未使用”当作人工复核清单，不要批量删除。

## 扫描结果说明

- `入口`：资源本身是 Build Settings 场景、Addressables 条目、Resources 资源或 StreamingAssets 文件。
- `可达`：从至少一个入口沿 Unity 依赖关系可以到达。
- `疑似未使用`：没有被当前入口集合到达，且不是编辑器/脚本类文件；不等于确定无用。
- `重复`：与至少另一个资源拥有相同的 SHA-256 文件内容。`.meta` 文件不参与哈希。
