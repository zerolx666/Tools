# Changelog

## 1.0.0

- Unity 2023.2 editor window.
- Direct dependencies and reverse references.
- Build Settings / Addressables / Resources / StreamingAssets entry reachability.
- Duplicate file detection by SHA-256.
- Suspected-unused candidates with safety caveats.
- CSV and JSON export.
