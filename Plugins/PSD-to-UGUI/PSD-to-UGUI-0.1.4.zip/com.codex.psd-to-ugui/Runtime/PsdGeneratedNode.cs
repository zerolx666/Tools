using UnityEngine;

namespace PsdToPrefab
{
    [DisallowMultipleComponent]
    public sealed class PsdGeneratedNode : MonoBehaviour
    {
        [HideInInspector] public string layerId;
        [HideInInspector] public bool obsolete;
    }
}
