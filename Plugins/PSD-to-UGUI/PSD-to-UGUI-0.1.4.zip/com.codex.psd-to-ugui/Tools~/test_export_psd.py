import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image
from psd_tools import PSDImage

from export_psd import export_document


class ExportPsdTests(unittest.TestCase):
    def test_preview_preserves_detail_above_1024_pixels(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "wide.psd"
            output = root / "output"
            psd = PSDImage.new("RGB", (2048, 64))
            psd.create_pixel_layer(Image.new("RGBA", (2048, 64), "#214365"), name="Background")
            psd.save(source)
            export_document(source, output)
            with Image.open(output / "preview.png") as preview:
                self.assertEqual(preview.size, (2048, 64))

    def test_exports_group_hierarchy_and_cropped_images(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "sample.psd"
            output = root / "output"
            psd = PSDImage.new("RGB", (64, 48))
            psd.create_pixel_layer(Image.new("RGBA", (64, 48), "#214365"), name="Background")
            panel = psd.create_group(name="Panel")
            panel.create_pixel_layer(Image.new("RGBA", (20, 10), "#f03020"), name="Button art", top=8, left=12)
            psd.save(source)

            export_document(source, output)

            manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual((manifest["width"], manifest["height"]), (64, 48))
            self.assertEqual([node["name"] for node in manifest["nodes"]], ["Background", "Panel", "Button art"])
            panel_node, child = manifest["nodes"][1:]
            self.assertEqual(child["parentId"], panel_node["id"])
            self.assertEqual((child["x"], child["y"], child["width"], child["height"]), (12, 8, 20, 10))
            with Image.open(output / child["asset"]) as rendered:
                self.assertEqual(rendered.size, (20, 10))
            self.assertTrue((output / "preview.png").exists())


if __name__ == "__main__":
    unittest.main()
