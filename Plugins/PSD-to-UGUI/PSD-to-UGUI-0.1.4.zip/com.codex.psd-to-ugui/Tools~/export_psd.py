"""导出 PSD 图层图片及供 Unity 编辑器读取的清单。"""

import argparse
import hashlib
import json
import sys
from pathlib import Path


def export_document(source: Path, destination: Path) -> None:
    try:
        from psd_tools import PSDImage
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError(
            "缺少 Python 依赖。请按插件 README.md 中的说明安装 requirements.txt。"
        ) from exc

    psd = PSDImage.open(source)
    destination.mkdir(parents=True, exist_ok=True)
    images = destination / "Images"
    images.mkdir(exist_ok=True)
    used_ids = set()
    nodes = []

    def visit(parent, parent_id: str, depth: int, index_path: str) -> None:
        # psd-tools iterates from the bottom layer to the top layer.
        for index, layer in enumerate(parent):
            path = f"{index_path}_{index}" if index_path else str(index)
            raw_id = getattr(layer, "layer_id", None)
            candidate = f"layer_{raw_id}" if isinstance(raw_id, int) and raw_id > 0 else f"path_{path}"
            layer_id = candidate if candidate not in used_ids else f"path_{path}"
            used_ids.add(layer_id)

            left, top, right, bottom = (int(value) for value in layer.bbox)
            width, height = max(0, right - left), max(0, bottom - top)
            visible = bool(layer.is_visible())
            group = bool(layer.is_group())
            text = ""
            if layer.kind == "type":
                try:
                    text = layer.text or ""
                except (AttributeError, ValueError):
                    pass

            asset = ""
            warning = ""
            if visible and width > 0 and height > 0:
                try:
                    rendered = layer.composite()
                    if rendered is not None:
                        rendered = rendered.convert("RGBA")
                        if rendered.size == (width, height):
                            filename = hashlib.sha1(layer_id.encode("utf-8")).hexdigest()[:16] + ".png"
                            rendered.save(images / filename)
                            asset = f"Images/{filename}"
                        else:
                            warning = f"渲染尺寸 {rendered.size} 与图层边界不一致"
                    else:
                        warning = "图层没有可渲染的像素"
                except Exception as exc:
                    warning = f"图层渲染失败：{type(exc).__name__}: {exc}"
            elif visible:
                warning = "图层边界为空"

            nodes.append(
                {
                    "id": layer_id,
                    "parentId": parent_id,
                    "name": layer.name or layer_id,
                    "x": left,
                    "y": top,
                    "width": width,
                    "height": height,
                    "kind": str(layer.kind),
                    "text": text,
                    "asset": asset,
                    "visible": visible,
                    "group": group,
                    "depth": depth,
                    "warning": warning,
                }
            )
            if group:
                visit(layer, layer_id, depth + 1, path)

    visit(psd, "", 0, "")
    try:
        preview = psd.composite()
        if preview is not None:
            preview = preview.convert("RGBA")
            # Preserve detail when zooming; bound memory for exceptionally large documents.
            preview.thumbnail((8192, 8192), Image.Resampling.LANCZOS)
            preview.save(destination / "preview.png")
    except Exception as exc:
        print(f"预览图渲染失败：{exc}", file=sys.stderr)

    manifest = {
        "version": 1,
        "name": source.stem,
        "width": psd.width,
        "height": psd.height,
        "nodes": nodes,
    }
    (destination / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"已导出 {len(nodes)} 个图层到 {destination}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        export_document(args.input.resolve(), args.output.resolve())
    except Exception as exc:
        print(f"PSD 导出失败：{exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
