using System;
using UnityEditor;
using UnityEngine;

namespace PsdToPrefab.Editor
{
    // Shared by the embedded preview and the independently resizable window.
    internal sealed class PsdPreviewView
    {
        internal const float MinZoom = 0.001f;
        internal const float MaxZoom = 32f;
        internal float Zoom { get; private set; } = 1f;
        internal Vector2 Center { get; private set; }
        private bool fit = true;
        private bool frameSelection;
        private PsdDocument currentDocument;
        private int currentSelection = -1;
        private Vector2 viewportSize;

        internal void Reset()
        {
            currentDocument = null;
            currentSelection = -1;
            fit = true;
            frameSelection = false;
        }

        internal void DrawToolbar(PsdDocument document, int selectedIndex)
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            if (GUILayout.Button("适应", EditorStyles.toolbarButton, GUILayout.Width(42)))
                fit = true;
            if (GUILayout.Button("1:1", EditorStyles.toolbarButton, GUILayout.Width(34)))
                SetZoom(1f, viewportSize * 0.5f);
            using (new EditorGUI.DisabledScope(document == null || selectedIndex < 0 || selectedIndex >= document.nodes.Count))
            {
                if (GUILayout.Button("定位选中", EditorStyles.toolbarButton, GUILayout.Width(64)))
                    frameSelection = true;
            }
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("−", EditorStyles.toolbarButton, GUILayout.Width(22)))
                SetZoom(Zoom / 1.25f, viewportSize * 0.5f);
            var percent = EditorGUILayout.DelayedFloatField(Zoom * 100f, GUILayout.Width(53));
            if (!Mathf.Approximately(percent, Zoom * 100f))
                SetZoom(percent / 100f, viewportSize * 0.5f);
            GUILayout.Label("%", GUILayout.Width(13));
            if (GUILayout.Button("+", EditorStyles.toolbarButton, GUILayout.Width(22)))
                SetZoom(Zoom * 1.25f, viewportSize * 0.5f);
            EditorGUILayout.EndHorizontal();
        }

        internal void Draw(Rect viewport, Texture2D texture, PsdDocument document, int selectedIndex,
            bool showAllBounds, Action repaint)
        {
            var control = GUIUtility.GetControlID("PsdPreview".GetHashCode(), FocusType.Passive, viewport);
            if (document == null || texture == null || document.width <= 0 || document.height <= 0)
            {
                GUI.Box(viewport, "无预览图，请重新解析 PSD。");
                return;
            }
            if (Event.current.type == EventType.Layout || viewport.width <= 1f || viewport.height <= 1f)
                return;

            viewportSize = viewport.size;
            if (!ReferenceEquals(currentDocument, document))
            {
                currentDocument = document;
                currentSelection = -1;
                fit = true;
            }
            var selected = selectedIndex >= 0 && selectedIndex < document.nodes.Count ? document.nodes[selectedIndex] : null;
            if (selectedIndex != currentSelection)
            {
                currentSelection = selectedIndex;
                // Keep the selected layer on screen when switching layers in a zoomed view.
                if (!fit && selected != null)
                    Center = LayerCenter(selected);
            }
            if (fit)
            {
                Zoom = FitZoom(viewportSize, new Vector2(document.width, document.height));
                Center = new Vector2(document.width * 0.5f, document.height * 0.5f);
            }
            if (frameSelection)
            {
                Frame(selected);
                frameSelection = false;
            }

            HandleInput(viewport, control, selected, repaint);
            EditorGUIUtility.AddCursorRect(viewport, MouseCursor.Pan);
            if (Event.current.type != EventType.Repaint)
                return;

            GUI.Box(viewport, GUIContent.none);
            GUI.BeginGroup(viewport);
            try
            {
                var clip = new Rect(Vector2.zero, viewport.size);
                var imageRect = ImageRect(viewport.size, new Vector2(document.width, document.height), Center, Zoom);
                EditorGUI.DrawTextureTransparent(imageRect, texture, ScaleMode.StretchToFill);
                if (showAllBounds)
                {
                    for (var i = 0; i < document.nodes.Count; i++)
                    {
                        var layer = document.nodes[i];
                        if (i != selectedIndex && layer.visible)
                            DrawBounds(imageRect, clip, document, layer, new Color(1f, 0.85f, 0.2f, 0.6f), null);
                    }
                }
                if (selected != null)
                {
                    DrawBounds(imageRect, clip, document, selected, new Color(0.2f, 1f, 0.35f),
                        (selectedIndex + 1) + ". " + selected.name);
                    if (!clip.Overlaps(PsdImportWindow.LayerPreviewRect(imageRect, document, selected)))
                        GUI.Label(new Rect(8, 8, Mathf.Max(1f, clip.width - 16f), 22), "图层在视野外，请点击“定位选中”。", EditorStyles.helpBox);
                }
            }
            finally { GUI.EndGroup(); }
        }

        internal static float FitZoom(Vector2 viewport, Vector2 content)
        {
            return Mathf.Clamp(Mathf.Min(Mathf.Max(1f, viewport.x - 20f) / Mathf.Max(1f, content.x),
                Mathf.Max(1f, viewport.y - 20f) / Mathf.Max(1f, content.y)), MinZoom, MaxZoom);
        }

        internal static Rect ImageRect(Vector2 viewport, Vector2 documentSize, Vector2 center, float zoom)
        {
            return new Rect(viewport * 0.5f - center * zoom, documentSize * zoom);
        }

        internal static Vector2 ZoomCenter(Vector2 center, Vector2 anchor, Vector2 viewport, float previous, float next)
        {
            return center + (anchor - viewport * 0.5f) * (1f / previous - 1f / next);
        }

        private static Vector2 LayerCenter(PsdLayer layer)
        {
            return new Vector2(layer.x + layer.width * 0.5f, layer.y + layer.height * 0.5f);
        }

        private void SetZoom(float next, Vector2 anchor)
        {
            if (float.IsNaN(next) || float.IsInfinity(next))
                return;
            next = Mathf.Clamp(next, MinZoom, MaxZoom);
            Center = ZoomCenter(Center, anchor, viewportSize, Zoom, next);
            Zoom = next;
            fit = false;
        }

        private void Frame(PsdLayer layer)
        {
            if (layer == null)
                return;
            Center = LayerCenter(layer);
            Zoom = FitZoom(viewportSize, new Vector2(Mathf.Max(1, layer.width), Mathf.Max(1, layer.height)) * 1.5f);
            fit = false;
        }

        private void HandleInput(Rect viewport, int control, PsdLayer selected, Action repaint)
        {
            var evt = Event.current;
            switch (evt.GetTypeForControl(control))
            {
                case EventType.ScrollWheel:
                    if (viewport.Contains(evt.mousePosition) && GUIUtility.hotControl == 0)
                    {
                        SetZoom(Zoom * Mathf.Pow(1.12f, -evt.delta.y), evt.mousePosition - viewport.position);
                        evt.Use();
                        repaint();
                    }
                    break;
                case EventType.MouseDown:
                    if ((evt.button == 0 || evt.button == 2) && viewport.Contains(evt.mousePosition))
                    {
                        GUIUtility.hotControl = control;
                        GUIUtility.keyboardControl = 0;
                        if (evt.button == 0 && evt.clickCount == 2)
                            Frame(selected);
                        evt.Use();
                        repaint();
                    }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == control)
                    {
                        Center -= evt.delta / Zoom;
                        fit = false;
                        evt.Use();
                        repaint();
                    }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == control)
                    {
                        GUIUtility.hotControl = 0;
                        evt.Use();
                    }
                    break;
                case EventType.Ignore:
                    if (GUIUtility.hotControl == control)
                        GUIUtility.hotControl = 0;
                    break;
            }
        }

        private static void DrawBounds(Rect imageRect, Rect clip, PsdDocument document, PsdLayer layer,
            Color color, string label)
        {
            if (layer.width <= 0 || layer.height <= 0)
                return;
            var bounds = PsdImportWindow.LayerPreviewRect(imageRect, document, layer);
            if (!clip.Overlaps(bounds))
                return;
            if (!string.IsNullOrEmpty(label))
            {
                var shadow = new Rect(bounds.x - 1, bounds.y - 1, bounds.width + 2, bounds.height + 2);
                Outline(shadow, new Color(0f, 0f, 0f, 0.9f), 4f);
            }
            Outline(bounds, color, string.IsNullOrEmpty(label) ? 1f : 2f);
            if (string.IsNullOrEmpty(label))
                return;
            if (bounds.width < 12f || bounds.height < 12f)
            {
                EditorGUI.DrawRect(new Rect(bounds.center.x - 8f, bounds.center.y - 1f, 16f, 2f), color);
                EditorGUI.DrawRect(new Rect(bounds.center.x - 1f, bounds.center.y - 8f, 2f, 16f), color);
            }
            var style = new GUIStyle(EditorStyles.miniBoldLabel) { padding = new RectOffset(4, 4, 0, 0) };
            style.normal.textColor = Color.white;
            var width = Mathf.Min(clip.width, style.CalcSize(new GUIContent(label)).x + 8f);
            var labelRect = new Rect(Mathf.Clamp(bounds.x, 0f, Mathf.Max(0f, clip.width - width)),
                Mathf.Clamp(bounds.y - 21f, 0f, Mathf.Max(0f, clip.height - 20f)), width, 20f);
            EditorGUI.DrawRect(labelRect, new Color(0.04f, 0.04f, 0.04f, 0.9f));
            GUI.Label(labelRect, label, style);
        }

        private static void Outline(Rect rect, Color color, float thickness)
        {
            var xThickness = Mathf.Min(thickness, rect.width);
            var yThickness = Mathf.Min(thickness, rect.height);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, yThickness), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - yThickness, rect.width, yThickness), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, xThickness, rect.height), color);
            EditorGUI.DrawRect(new Rect(rect.xMax - xThickness, rect.y, xThickness, rect.height), color);
        }
    }

    internal sealed class PsdPreviewWindow : EditorWindow
    {
        [SerializeField] private PsdImportWindow owner;
        private readonly PsdPreviewView view = new PsdPreviewView();

        internal void Bind(PsdImportWindow source)
        {
            owner = source;
            minSize = new Vector2(560, 400);
            titleContent = new GUIContent("PSD 图层定位");
        }

        private void OnGUI()
        {
            if (owner == null)
            {
                EditorGUILayout.HelpBox("请在 PSD 转 UGUI 窗口解析 PSD，然后打开独立预览。", MessageType.Info);
                return;
            }
            owner.DrawExpandedPreview(view, Repaint);
        }
    }
}
