using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;

namespace PsdToPrefab.Editor
{
    internal sealed class PsdImportWindow : EditorWindow
    {
        private const string PythonPreference = "PsdToPrefab.Python";
        private const string OutputPreference = "PsdToPrefab.Output";
        private static readonly PsdNodeType[] GroupTypes =
            { PsdNodeType.Container, PsdNodeType.Button, PsdNodeType.FlattenedImage, PsdNodeType.Ignore };
        private static readonly PsdNodeType[] LeafTypes =
            { PsdNodeType.Image, PsdNodeType.Button, PsdNodeType.Text, PsdNodeType.Container, PsdNodeType.Ignore };
        private static readonly string[] AnchorNames =
        {
            "居中", "左上", "上方", "右上", "左侧", "右侧", "左下", "下方", "右下",
            "横向拉伸", "纵向拉伸", "双向拉伸"
        };
        private static readonly TextAnchor[] Alignments =
        {
            TextAnchor.UpperLeft, TextAnchor.UpperCenter, TextAnchor.UpperRight,
            TextAnchor.MiddleLeft, TextAnchor.MiddleCenter, TextAnchor.MiddleRight,
            TextAnchor.LowerLeft, TextAnchor.LowerCenter, TextAnchor.LowerRight
        };
        private static readonly string[] AlignmentNames =
        {
            "左上", "上中", "右上", "左中", "居中", "右中", "左下", "下中", "右下"
        };

        [SerializeField] private string sourcePath = "";
        [SerializeField] private string pythonExecutable = "python";
        [SerializeField] private string outputRoot = "Assets/PSDUI";
        private string stagingFolder;
        private DateTime analyzedWriteTime;
        private PsdDocument document;
        private PsdImportSettings settings;
        private Texture2D preview;
        private Texture2D selectedPreview;
        private string selectedPreviewMessage = "";
        private string selectedLayerPath = "";
        private readonly PsdPreviewView previewView = new PsdPreviewView();
        private PsdPreviewWindow expandedPreview;
        private Vector2 listScroll;
        private Vector2 detailsScroll;
        private int selectedIndex = -1;
        private bool showAllBounds;
        private string status = "";
        private MessageType statusType = MessageType.Info;

        [MenuItem("工具/PSD 转 UGUI 预制体")]
        private static void Open()
        {
            GetWindow<PsdImportWindow>("PSD 转 UGUI").minSize = new Vector2(760, 520);
        }

        private void OnEnable()
        {
            pythonExecutable = EditorPrefs.GetString(PythonPreference, "python");
            outputRoot = EditorPrefs.GetString(OutputPreference, "Assets/PSDUI");
        }

        private void OnDisable()
        {
            if (expandedPreview != null)
                expandedPreview.Close();
            ReleaseSelectedPreview();
            if (preview != null)
                DestroyImmediate(preview);
            DeleteStagingFolder();
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            sourcePath = EditorGUILayout.TextField("PSD / PSB 文件", sourcePath);
            if (GUILayout.Button("浏览", GUILayout.Width(70)))
                BrowseSource();
            EditorGUILayout.EndHorizontal();

            var newPython = EditorGUILayout.TextField("Python 路径", pythonExecutable);
            if (newPython != pythonExecutable)
            {
                pythonExecutable = newPython;
                EditorPrefs.SetString(PythonPreference, pythonExecutable);
            }

            EditorGUILayout.BeginHorizontal();
            var newOutput = EditorGUILayout.TextField("输出目录", outputRoot);
            if (newOutput != outputRoot)
            {
                outputRoot = newOutput.Replace('\\', '/');
                EditorPrefs.SetString(OutputPreference, outputRoot);
            }
            if (GUILayout.Button("浏览", GUILayout.Width(70)))
                BrowseOutput();
            EditorGUILayout.EndHorizontal();

            if (GUILayout.Button("解析 PSD", GUILayout.Height(28)))
                Analyze();
            if (!string.IsNullOrEmpty(status))
                EditorGUILayout.HelpBox(status, statusType);
            if (document == null)
                return;

            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField($"{document.name}  |  {document.width} x {document.height}  |  {document.nodes.Count} 个图层", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal(GUILayout.ExpandHeight(true));
            DrawLayerList();
            DrawDetails();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(8);
            if (GUILayout.Button("生成 / 更新预制体", GUILayout.Height(32)))
                Generate();
        }

        internal static string SourceBrowseDirectory(string path, string fallbackDirectory)
        {
            if (string.IsNullOrWhiteSpace(path))
                return fallbackDirectory;
            try
            {
                var directory = Path.GetDirectoryName(Path.GetFullPath(path));
                return Directory.Exists(directory) ? directory : fallbackDirectory;
            }
            catch (ArgumentException) { return fallbackDirectory; }
            catch (NotSupportedException) { return fallbackDirectory; }
            catch (IOException) { return fallbackDirectory; }
        }

        private void BrowseSource()
        {
            try
            {
                var initialDirectory = SourceBrowseDirectory(sourcePath, Application.dataPath);
                var chosen = EditorUtility.OpenFilePanel("选择 PSD 或 PSB 文件", initialDirectory, "");
                if (!string.IsNullOrEmpty(chosen))
                {
                    sourcePath = chosen;
                    SetStatus("", MessageType.Info);
                }
            }
            catch (Exception exc)
            {
                SetStatus("无法打开 PSD 文件选择窗口：" + exc.Message, MessageType.Error);
                Debug.LogException(exc);
            }
        }

        private void BrowseOutput()
        {
            try
            {
                var chosen = EditorUtility.OpenFolderPanel("选择 Assets 内的输出目录", Application.dataPath, "");
                if (string.IsNullOrEmpty(chosen))
                    return;
                var project = Path.GetDirectoryName(Application.dataPath).Replace('\\', '/');
                var normalized = Path.GetFullPath(chosen).Replace('\\', '/');
                if (normalized.Equals(project + "/Assets", StringComparison.OrdinalIgnoreCase) ||
                    normalized.StartsWith(project + "/Assets/", StringComparison.OrdinalIgnoreCase))
                {
                    outputRoot = normalized.Substring(project.Length + 1);
                    EditorPrefs.SetString(OutputPreference, outputRoot);
                    SetStatus("", MessageType.Info);
                }
                else
                    SetStatus("请选择当前项目 Assets 目录内的文件夹。", MessageType.Error);
            }
            catch (Exception exc)
            {
                SetStatus("无法打开输出目录选择窗口：" + exc.Message, MessageType.Error);
                Debug.LogException(exc);
            }
        }

        private void DrawLayerList()
        {
            EditorGUILayout.BeginVertical(GUILayout.MinWidth(400));
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label("图层", GUILayout.Width(180));
            GUILayout.Label("节点类型", GUILayout.Width(115));
            GUILayout.Label("锚点");
            EditorGUILayout.EndHorizontal();
            listScroll = EditorGUILayout.BeginScrollView(listScroll);
            for (var i = 0; i < document.nodes.Count; i++)
            {
                var layer = document.nodes[i];
                var option = settings.options[i];
                EditorGUILayout.BeginHorizontal();
                GUILayout.Space(Mathf.Min(layer.depth, 10) * 12);
                var label = $"{i + 1}. " + (layer.group ? "▸ " + layer.name : layer.name);
                if (GUILayout.Toggle(selectedIndex == i, label, "Button", GUILayout.MinWidth(70), GUILayout.ExpandWidth(true)))
                    SelectLayer(i);
                var choices = layer.group ? GroupTypes : LeafTypes;
                var names = choices.Select(TypeName).ToArray();
                var selected = Array.IndexOf(choices, option.type);
                selected = EditorGUILayout.Popup(Mathf.Max(0, selected), names, GUILayout.Width(115));
                option.type = choices[selected];
                option.anchor = (PsdAnchor)EditorGUILayout.Popup((int)option.anchor, AnchorNames, GUILayout.Width(120));
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void DrawDetails()
        {
            var detailsWidth = Mathf.Clamp(position.width * 0.43f, 320f, 640f);
            EditorGUILayout.BeginVertical(GUILayout.Width(detailsWidth));
            detailsScroll = EditorGUILayout.BeginScrollView(detailsScroll);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("预览定位", EditorStyles.boldLabel);
            var allBounds = GUILayout.Toggle(showAllBounds, "全部边界", EditorStyles.miniButton, GUILayout.Width(64));
            if (allBounds != showAllBounds)
            {
                showAllBounds = allBounds;
                RepaintPreviews();
            }
            if (GUILayout.Button("独立窗口", EditorStyles.miniButton, GUILayout.Width(64)))
                OpenExpandedPreview();
            EditorGUILayout.EndHorizontal();
            previewView.DrawToolbar(document, selectedIndex);
            var rect = GUILayoutUtility.GetRect(GUIContent.none, GUIStyle.none, GUILayout.ExpandWidth(true),
                GUILayout.Height(Mathf.Clamp(position.height * 0.36f, 180f, 420f)));
            previewView.Draw(rect, preview, document, selectedIndex, showAllBounds, RepaintPreviews);
            EditorGUILayout.LabelField("滚轮缩放 · 左键/中键拖动 · 双击定位选中", EditorStyles.miniLabel);
            if (selectedIndex >= 0 && selectedIndex < document.nodes.Count)
            {
                var layer = document.nodes[selectedIndex];
                var option = settings.options[selectedIndex];
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField($"图层 {selectedIndex + 1}/{document.nodes.Count}：{layer.name}", EditorStyles.boldLabel);
                EditorGUILayout.LabelField($"{KindName(layer.kind)} | {layer.x}, {layer.y} | {layer.width} x {layer.height}", EditorStyles.miniLabel);
                EditorGUILayout.LabelField("分组路径（可复制）", EditorStyles.miniBoldLabel);
                var pathHeight = Mathf.Max(32f, EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent(selectedLayerPath),
                    detailsWidth - 28f));
                EditorGUILayout.SelectableLabel(selectedLayerPath, EditorStyles.wordWrappedLabel, GUILayout.Height(pathHeight));
                EditorGUILayout.LabelField("独立图层预览", EditorStyles.boldLabel);
                var thumbnailRect = GUILayoutUtility.GetRect(GUIContent.none, GUIStyle.none,
                    GUILayout.ExpandWidth(true), GUILayout.Height(120f));
                if (selectedPreview != null)
                    EditorGUI.DrawTextureTransparent(thumbnailRect, selectedPreview, ScaleMode.ScaleToFit);
                else
                    GUI.Box(thumbnailRect, selectedPreviewMessage);
                if (!string.IsNullOrEmpty(layer.warning))
                    EditorGUILayout.HelpBox(layer.warning, MessageType.Warning);
                if (!layer.visible)
                    EditorGUILayout.HelpBox("隐藏图层会被跳过。", MessageType.Info);
                if (option.type == PsdNodeType.Text)
                {
                    option.text = EditorGUILayout.TextArea(option.text, GUILayout.MinHeight(52));
                    option.fontSize = EditorGUILayout.IntField("字号", option.fontSize);
                    option.textColor = EditorGUILayout.ColorField("文字颜色", option.textColor);
                    var alignmentIndex = Mathf.Max(0, Array.IndexOf(Alignments, option.textAlignment));
                    option.textAlignment = Alignments[EditorGUILayout.Popup("对齐方式", alignmentIndex, AlignmentNames)];
                }
                if (option.type == PsdNodeType.Image || option.type == PsdNodeType.FlattenedImage ||
                    (option.type == PsdNodeType.Button && !layer.group))
                {
                    option.sliced = EditorGUILayout.Toggle("九宫格", option.sliced);
                    if (option.sliced)
                    {
                        option.spriteBorder.x = EditorGUILayout.FloatField("左边距", option.spriteBorder.x);
                        option.spriteBorder.y = EditorGUILayout.FloatField("下边距", option.spriteBorder.y);
                        option.spriteBorder.z = EditorGUILayout.FloatField("右边距", option.spriteBorder.z);
                        option.spriteBorder.w = EditorGUILayout.FloatField("上边距", option.spriteBorder.w);
                    }
                }
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void SelectLayer(int index)
        {
            if (index == selectedIndex || document == null || index < 0 || index >= document.nodes.Count)
                return;
            selectedIndex = index;
            ReleaseSelectedPreview();
            var layer = document.nodes[index];
            selectedLayerPath = LayerHierarchyPath(document, layer);
            selectedPreviewMessage = !layer.visible ? "隐藏图层没有导出图片" : "此图层没有可用图片";
            try
            {
                if (!string.IsNullOrEmpty(layer.asset) && !string.IsNullOrEmpty(stagingFolder))
                {
                    var root = Path.GetFullPath(stagingFolder) + Path.DirectorySeparatorChar;
                    var path = Path.GetFullPath(Path.Combine(stagingFolder, layer.asset));
                    if (path.StartsWith(root, StringComparison.OrdinalIgnoreCase) && File.Exists(path))
                    {
                        selectedPreview = new Texture2D(2, 2) { hideFlags = HideFlags.HideAndDontSave };
                        if (!selectedPreview.LoadImage(File.ReadAllBytes(path)))
                            throw new InvalidOperationException("图层图片格式无效。");
                    }
                }
            }
            catch (Exception exc)
            {
                ReleaseSelectedPreview();
                selectedPreviewMessage = "图层预览读取失败：" + exc.Message;
            }
            RepaintPreviews();
        }

        private void ReleaseSelectedPreview()
        {
            if (selectedPreview != null)
                DestroyImmediate(selectedPreview);
            selectedPreview = null;
        }

        internal static string LayerHierarchyPath(PsdDocument source, PsdLayer layer)
        {
            var names = new List<string>();
            var visited = new HashSet<PsdLayer>();
            while (layer != null && visited.Add(layer))
            {
                names.Add(layer.name);
                var parentId = layer.parentId;
                layer = string.IsNullOrEmpty(parentId) ? null : source.nodes.FirstOrDefault(node => node.id == parentId);
            }
            names.Reverse();
            return string.Join(" / ", names);
        }

        private void OpenExpandedPreview()
        {
            if (expandedPreview == null)
            {
                expandedPreview = CreateInstance<PsdPreviewWindow>();
                expandedPreview.position = new Rect(position.x + 30f, position.y + 30f, 1000f, 700f);
            }
            expandedPreview.Bind(this);
            expandedPreview.Show();
            expandedPreview.Focus();
        }

        internal void DrawExpandedPreview(PsdPreviewView view, Action repaint)
        {
            if (document == null)
            {
                EditorGUILayout.HelpBox("请先在主窗口解析 PSD。", MessageType.Info);
                return;
            }
            var path = selectedIndex >= 0 ? selectedLayerPath : document.name;
            var pathHeight = Mathf.Max(32f, EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent(path),
                Mathf.Max(1f, EditorGUIUtility.currentViewWidth - 16f)));
            EditorGUILayout.SelectableLabel(path, EditorStyles.wordWrappedLabel, GUILayout.Height(pathHeight));
            view.DrawToolbar(document, selectedIndex);
            var rect = GUILayoutUtility.GetRect(GUIContent.none, GUIStyle.none, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            view.Draw(rect, preview, document, selectedIndex, showAllBounds, repaint);
            EditorGUILayout.LabelField("滚轮围绕鼠标缩放 · 左键/中键拖动 · 双击或“定位选中”放大图层 · “适应”查看整图", EditorStyles.miniLabel);
            if (preview != null && (preview.width < document.width || preview.height < document.height))
                EditorGUILayout.LabelField("整图预览分辨率：" + preview.width + " × " + preview.height, EditorStyles.miniLabel);
        }

        private void RepaintPreviews()
        {
            Repaint();
            if (expandedPreview != null)
                expandedPreview.Repaint();
        }

        internal static Rect LayerPreviewRect(Rect imageRect, PsdDocument sourceDocument, PsdLayer layer)
        {
            return new Rect(
                imageRect.x + imageRect.width * layer.x / sourceDocument.width,
                imageRect.y + imageRect.height * layer.y / sourceDocument.height,
                imageRect.width * layer.width / sourceDocument.width,
                imageRect.height * layer.height / sourceDocument.height);
        }

        private void Analyze()
        {
            ReleaseSelectedPreview();
            previewView.Reset();
            DeleteStagingFolder();
            document = null;
            settings = null;
            selectedIndex = -1;
            if (preview != null)
            {
                DestroyImmediate(preview);
                preview = null;
            }
            try
            {
                if (!File.Exists(sourcePath) || !new[] { ".psd", ".psb" }.Contains(Path.GetExtension(sourcePath).ToLowerInvariant()))
                    throw new InvalidOperationException("请选择已有的 PSD 或 PSB 文件。");
                PsdPrefabBuilder.AssetToAbsolute(outputRoot);
                var package = PackageInfo.FindForAssetPath("Packages/com.codex.psd-to-ugui/Editor/PsdImportWindow.cs");
                if (package == null)
                    throw new InvalidOperationException("无法定位已安装的 PSD 转 UGUI 插件包。");
                var script = Path.Combine(package.resolvedPath, "Tools~", "export_psd.py");
                if (!File.Exists(script))
                    throw new FileNotFoundException("插件内缺少 PSD 解析脚本。", script);
                stagingFolder = Path.Combine(Path.GetTempPath(), "PsdToPrefab", Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(stagingFolder);
                EditorUtility.DisplayProgressBar("PSD 转 UGUI", "正在读取 PSD 图层...", 0.3f);
                var start = new ProcessStartInfo
                {
                    FileName = pythonExecutable,
                    Arguments = $"\"{script}\" --input \"{Path.GetFullPath(sourcePath)}\" --output \"{stagingFolder}\"",
                    WorkingDirectory = Path.GetDirectoryName(Application.dataPath),
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8
                };
                start.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
                using (var process = Process.Start(start))
                {
                    if (process == null)
                        throw new InvalidOperationException("无法启动 Python，请检查 Python 路径。");
                    Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
                    Task<string> errorTask = process.StandardError.ReadToEndAsync();
                    if (!process.WaitForExit(300000))
                    {
                        process.Kill();
                        throw new TimeoutException("PSD 解析超过五分钟，已停止。");
                    }
                    Task.WaitAll(outputTask, errorTask);
                    if (process.ExitCode != 0)
                        throw new InvalidOperationException(errorTask.Result.Trim());
                    Debug.Log(outputTask.Result.Trim());
                }
                var json = File.ReadAllText(Path.Combine(stagingFolder, "manifest.json"));
                document = JsonUtility.FromJson<PsdDocument>(json);
                if (document == null || document.version != 1 || document.nodes == null)
                    throw new InvalidOperationException("PSD 解析脚本返回了无效的数据。");
                analyzedWriteTime = File.GetLastWriteTimeUtc(sourcePath);
                LoadSettings();
                var previewPath = Path.Combine(stagingFolder, "preview.png");
                if (File.Exists(previewPath))
                {
                    preview = new Texture2D(2, 2);
                    preview.LoadImage(File.ReadAllBytes(previewPath));
                    preview.hideFlags = HideFlags.HideAndDontSave;
                }
                if (document.nodes.Count > 0)
                    SelectLayer(0);
                SetStatus("解析完成。选中图层可查看位置，滚轮缩放预览；可打开独立窗口查看大图。", MessageType.Info);
            }
            catch (System.ComponentModel.Win32Exception exc)
            {
                document = null;
                DeleteStagingFolder();
                SetStatus("无法启动 Python，请确认 Python 路径和依赖安装。", MessageType.Error);
                Debug.LogException(exc);
            }
            catch (Exception exc)
            {
                document = null;
                DeleteStagingFolder();
                SetStatus(exc.Message, MessageType.Error);
                Debug.LogException(exc);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void LoadSettings()
        {
            var folder = PsdPrefabBuilder.OutputFolder(outputRoot, document.name);
            var path = PsdPrefabBuilder.AssetToAbsolute(PsdPrefabBuilder.SettingsPath(folder));
            PsdImportSettings previous = null;
            if (File.Exists(path))
                previous = JsonUtility.FromJson<PsdImportSettings>(File.ReadAllText(path));
            var sameSource = previous != null && !string.IsNullOrEmpty(previous.sourcePath) &&
                             string.Equals(Path.GetFullPath(previous.sourcePath), Path.GetFullPath(sourcePath), StringComparison.OrdinalIgnoreCase);
            var previousOptions = sameSource && previous.options != null
                ? previous.options.Where(option => !string.IsNullOrEmpty(option.id)).GroupBy(option => option.id).ToDictionary(group => group.Key, group => group.First())
                : new Dictionary<string, PsdNodeOption>();
            settings = new PsdImportSettings { sourcePath = Path.GetFullPath(sourcePath) };
            foreach (var layer in document.nodes)
            {
                if (!previousOptions.TryGetValue(layer.id, out var option))
                    option = new PsdNodeOption
                    {
                        id = layer.id,
                        type = !layer.visible ? PsdNodeType.Ignore : layer.group ? PsdNodeType.Container :
                            !string.IsNullOrEmpty(layer.asset) ? PsdNodeType.Image :
                            !string.IsNullOrEmpty(layer.text) ? PsdNodeType.Text : PsdNodeType.Ignore,
                        text = layer.text
                    };
                settings.options.Add(option);
            }
        }

        private void Generate()
        {
            try
            {
                if (document == null || settings == null || !Directory.Exists(stagingFolder))
                    throw new InvalidOperationException("请先解析 PSD 文件。");
                if (File.GetLastWriteTimeUtc(sourcePath) != analyzedWriteTime)
                    throw new InvalidOperationException("PSD 文件在解析后发生变化，请重新解析。");
                EditorUtility.DisplayProgressBar("PSD 转 UGUI", "正在生成图片和预制体...", 0.6f);
                var prefabPath = PsdPrefabBuilder.Build(document, settings, stagingFolder, outputRoot);
                Selection.activeObject = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                EditorGUIUtility.PingObject(Selection.activeObject);
                SetStatus("预制体已保存：" + prefabPath, MessageType.Info);
            }
            catch (Exception exc)
            {
                SetStatus(exc.Message, MessageType.Error);
                Debug.LogException(exc);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void SetStatus(string message, MessageType type)
        {
            status = message;
            statusType = type;
            Repaint();
        }

        private void DeleteStagingFolder()
        {
            if (string.IsNullOrEmpty(stagingFolder))
                return;
            var root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "PsdToPrefab"));
            var target = Path.GetFullPath(stagingFolder);
            if (target.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) &&
                Directory.Exists(target))
                Directory.Delete(target, true);
            stagingFolder = null;
        }

        private static string TypeName(PsdNodeType type)
        {
            switch (type)
            {
                case PsdNodeType.Container: return "容器";
                case PsdNodeType.Image: return "图片";
                case PsdNodeType.Button: return "按钮";
                case PsdNodeType.Text: return "可编辑文字";
                case PsdNodeType.Ignore: return "忽略";
                case PsdNodeType.FlattenedImage: return "合并为图片";
                default: return type.ToString();
            }
        }

        private static string KindName(string kind)
        {
            switch (kind)
            {
                case "type": return "文字图层";
                case "pixel": return "像素图层";
                case "shape": return "形状图层";
                case "group": return "图层组";
                default: return kind;
            }
        }
    }
}
