using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace PsdToPrefab.Editor
{
    internal static class PsdPrefabBuilder
    {
        internal static string OutputFolder(string root, string documentName)
        {
            var safeName = string.Concat(documentName.Select(ch =>
                Array.IndexOf(Path.GetInvalidFileNameChars(), ch) >= 0 ? '_' : ch)).Trim().Trim('.');
            if (string.IsNullOrEmpty(safeName))
                safeName = "ImportedUI";
            return root.TrimEnd('/') + "/" + safeName;
        }

        internal static string SettingsPath(string folder)
        {
            return folder + "/import-settings.json";
        }

        internal static string AssetToAbsolute(string assetPath)
        {
            if (assetPath != "Assets" && !assetPath.StartsWith("Assets/", StringComparison.Ordinal))
                throw new ArgumentException("输出目录必须位于当前项目的 Assets 内。");
            var assetsRoot = Path.GetFullPath(Application.dataPath);
            var absolute = Path.GetFullPath(Path.Combine(assetsRoot, assetPath.Substring("Assets".Length).TrimStart('/').Replace('/', Path.DirectorySeparatorChar)));
            if (absolute != assetsRoot && !absolute.StartsWith(assetsRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("输出目录不能超出当前项目的 Assets。");
            return absolute;
        }

        internal static string Build(PsdDocument document, PsdImportSettings settings, string stagingFolder, string outputRoot)
        {
            if (document == null || document.version != 1 || document.width <= 0 || document.height <= 0)
                throw new InvalidOperationException("PSD 解析数据无效或版本不受支持。");
            if (document.nodes == null || settings.options == null)
                throw new InvalidOperationException("PSD 图层数据或导入选项不完整。");

            var folder = OutputFolder(outputRoot, document.name);
            var absoluteFolder = AssetToAbsolute(folder);
            var settingsPath = SettingsPath(folder);
            if (File.Exists(AssetToAbsolute(settingsPath)))
            {
                var previous = JsonUtility.FromJson<PsdImportSettings>(File.ReadAllText(AssetToAbsolute(settingsPath)));
                if (previous == null || string.IsNullOrEmpty(previous.sourcePath) ||
                    !string.Equals(Path.GetFullPath(previous.sourcePath), Path.GetFullPath(settings.sourcePath), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("此输出目录已关联另一份 PSD，请选择其他输出目录。");
            }

            var optionById = settings.options.ToDictionary(option => option.id);
            var layerById = document.nodes.ToDictionary(layer => layer.id);
            var suppressed = new HashSet<string>();
            var activeLayers = new List<PsdLayer>();
            foreach (var layer in document.nodes)
            {
                if (!optionById.TryGetValue(layer.id, out var option))
                    throw new InvalidOperationException("图层缺少导入选项：" + layer.name);
                if (suppressed.Contains(layer.parentId) || option.type == PsdNodeType.Ignore || !layer.visible)
                {
                    suppressed.Add(layer.id);
                    continue;
                }
                if (layer.group && option.type == PsdNodeType.Text)
                    throw new InvalidOperationException("图层组不能转换为可编辑文字：" + layer.name);
                if (!layer.group && option.type == PsdNodeType.FlattenedImage)
                    throw new InvalidOperationException("只有图层组可以合并为图片：" + layer.name);
                if (RequiresSprite(layer, option) && string.IsNullOrEmpty(layer.asset))
                    throw new InvalidOperationException("图层没有可用图片：" + layer.name);
                activeLayers.Add(layer);
                if (option.type == PsdNodeType.FlattenedImage)
                    suppressed.Add(layer.id);
            }

            Directory.CreateDirectory(absoluteFolder);
            var spritePaths = new Dictionary<string, string>();
            foreach (var layer in activeLayers)
            {
                var option = optionById[layer.id];
                if (!RequiresSprite(layer, option))
                    continue;
                var source = Path.GetFullPath(Path.Combine(stagingFolder, layer.asset.Replace('/', Path.DirectorySeparatorChar)));
                if (!File.Exists(source) || !source.StartsWith(Path.GetFullPath(stagingFolder) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("找不到图层导出的图片：" + layer.name);
                var assetPath = folder + "/Images/" + Path.GetFileName(layer.asset);
                var target = AssetToAbsolute(assetPath);
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                File.Copy(source, target, true);
                spritePaths[layer.id] = assetPath;
            }

            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            foreach (var layer in activeLayers)
            {
                if (!spritePaths.TryGetValue(layer.id, out var path))
                    continue;
                var option = optionById[layer.id];
                var importer = AssetImporter.GetAtPath(path) as TextureImporter;
                if (importer == null)
                    throw new InvalidOperationException("Unity 无法导入图片：" + path);
                var border = option.sliced ? option.spriteBorder : Vector4.zero;
                if (importer.textureType != TextureImporterType.Sprite ||
                    importer.spriteImportMode != SpriteImportMode.Single ||
                    importer.mipmapEnabled || importer.spriteBorder != border)
                {
                    importer.textureType = TextureImporterType.Sprite;
                    importer.spriteImportMode = SpriteImportMode.Single;
                    importer.mipmapEnabled = false;
                    importer.alphaIsTransparency = true;
                    importer.spriteBorder = border;
                    importer.SaveAndReimport();
                }
            }

            var prefabPath = folder + "/" + Path.GetFileName(folder) + ".prefab";
            var exists = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath) != null;
            GameObject root = null;
            try
            {
                root = exists ? PrefabUtility.LoadPrefabContents(prefabPath) : new GameObject(document.name, typeof(RectTransform));
                var rootMarker = root.GetComponent<PsdGeneratedNode>();
                if (exists && (rootMarker == null || rootMarker.layerId != "__root__"))
                    throw new InvalidOperationException("同名预制体不是由此插件生成的，已停止覆盖：" + prefabPath);
                if (rootMarker == null)
                    rootMarker = root.AddComponent<PsdGeneratedNode>();
                rootMarker.layerId = "__root__";
                rootMarker.obsolete = false;
                root.name = document.name;

                var rootRect = root.GetComponent<RectTransform>();
                rootRect.anchorMin = rootRect.anchorMax = rootRect.pivot = new Vector2(0.5f, 0.5f);
                rootRect.anchoredPosition = Vector2.zero;
                rootRect.sizeDelta = new Vector2(document.width, document.height);

                var knownNodes = root.GetComponentsInChildren<PsdGeneratedNode>(true)
                    .Where(node => node != rootMarker && !string.IsNullOrEmpty(node.layerId))
                    .GroupBy(node => node.layerId)
                    .ToDictionary(group => group.Key, group => group.First());
                var transforms = new Dictionary<string, RectTransform> { [""] = rootRect };
                var activeIds = new HashSet<string>();
                foreach (var layer in activeLayers)
                {
                    if (!transforms.TryGetValue(layer.parentId, out var parent))
                        throw new InvalidOperationException("图层缺少父节点：" + layer.name);
                    if (!knownNodes.TryGetValue(layer.id, out var marker))
                    {
                        var gameObject = new GameObject(layer.name, typeof(RectTransform), typeof(PsdGeneratedNode));
                        marker = gameObject.GetComponent<PsdGeneratedNode>();
                    }
                    var rect = (RectTransform)marker.transform;
                    rect.SetParent(parent, false);
                    rect.SetAsLastSibling();
                    rect.gameObject.name = layer.name;
                    rect.gameObject.SetActive(true);
                    marker.layerId = layer.id;
                    marker.obsolete = false;
                    var parentBounds = string.IsNullOrEmpty(layer.parentId) ? null : layerById[layer.parentId];
                    ApplyRect(rect, layer, parentBounds, document, optionById[layer.id].anchor);
                    ApplyVisual(rect.gameObject, layer, optionById[layer.id], spritePaths);
                    transforms[layer.id] = rect;
                    activeIds.Add(layer.id);
                }

                foreach (var marker in knownNodes.Values)
                {
                    if (activeIds.Contains(marker.layerId))
                        continue;
                    marker.obsolete = true;
                    marker.gameObject.SetActive(false);
                }

                if (PrefabUtility.SaveAsPrefabAsset(root, prefabPath) == null)
                    throw new InvalidOperationException("Unity 保存预制体失败：" + prefabPath);
            }
            finally
            {
                if (root != null)
                {
                    if (exists)
                        PrefabUtility.UnloadPrefabContents(root);
                    else
                        UnityEngine.Object.DestroyImmediate(root);
                }
            }

            File.WriteAllText(AssetToAbsolute(settingsPath), JsonUtility.ToJson(settings, true));
            AssetDatabase.ImportAsset(settingsPath);
            return prefabPath;
        }

        private static bool RequiresSprite(PsdLayer layer, PsdNodeOption option)
        {
            return option.type == PsdNodeType.Image || option.type == PsdNodeType.FlattenedImage ||
                   (option.type == PsdNodeType.Button && !layer.group);
        }

        private static void ApplyRect(RectTransform rect, PsdLayer layer, PsdLayer parent, PsdDocument document, PsdAnchor anchor)
        {
            var parentX = parent != null ? parent.x : 0;
            var parentY = parent != null ? parent.y : 0;
            var parentWidth = parent != null ? parent.width : document.width;
            var parentHeight = parent != null ? parent.height : document.height;
            var left = layer.x - parentX;
            var top = layer.y - parentY;
            var right = left + layer.width;
            var bottom = top + layer.height;
            rect.pivot = new Vector2(0.5f, 0.5f);

            if (anchor == PsdAnchor.StretchBoth || anchor == PsdAnchor.StretchHorizontal || anchor == PsdAnchor.StretchVertical)
            {
                var horizontal = anchor != PsdAnchor.StretchVertical;
                var vertical = anchor != PsdAnchor.StretchHorizontal;
                rect.anchorMin = new Vector2(horizontal ? 0f : 0.5f, vertical ? 0f : 0.5f);
                rect.anchorMax = new Vector2(horizontal ? 1f : 0.5f, vertical ? 1f : 0.5f);
                rect.sizeDelta = new Vector2(horizontal ? 0f : layer.width, vertical ? 0f : layer.height);
                rect.anchoredPosition = new Vector2(horizontal ? 0f : left + layer.width / 2f - parentWidth / 2f,
                    vertical ? 0f : parentHeight / 2f - top - layer.height / 2f);
                rect.offsetMin = new Vector2(horizontal ? left : rect.offsetMin.x, vertical ? parentHeight - bottom : rect.offsetMin.y);
                rect.offsetMax = new Vector2(horizontal ? right - parentWidth : rect.offsetMax.x, vertical ? parentHeight - top : rect.offsetMax.y);
                return;
            }

            var point = AnchorPoint(anchor);
            rect.anchorMin = rect.anchorMax = point;
            rect.sizeDelta = new Vector2(layer.width, layer.height);
            rect.anchoredPosition = new Vector2(left + layer.width / 2f - parentWidth * point.x,
                parentHeight * (1f - point.y) - top - layer.height / 2f);
        }

        private static Vector2 AnchorPoint(PsdAnchor anchor)
        {
            switch (anchor)
            {
                case PsdAnchor.TopLeft: return new Vector2(0, 1);
                case PsdAnchor.Top: return new Vector2(0.5f, 1);
                case PsdAnchor.TopRight: return new Vector2(1, 1);
                case PsdAnchor.Left: return new Vector2(0, 0.5f);
                case PsdAnchor.Right: return new Vector2(1, 0.5f);
                case PsdAnchor.BottomLeft: return new Vector2(0, 0);
                case PsdAnchor.Bottom: return new Vector2(0.5f, 0);
                case PsdAnchor.BottomRight: return new Vector2(1, 0);
                default: return new Vector2(0.5f, 0.5f);
            }
        }

        private static void ApplyVisual(GameObject gameObject, PsdLayer layer, PsdNodeOption option, Dictionary<string, string> spritePaths)
        {
            var image = gameObject.GetComponent<Image>();
            var button = gameObject.GetComponent<Button>();
            var text = gameObject.GetComponent<Text>();
            if (option.type != PsdNodeType.Text && text != null)
                UnityEngine.Object.DestroyImmediate(text);
            if (option.type != PsdNodeType.Button && button != null)
                UnityEngine.Object.DestroyImmediate(button);

            if (option.type == PsdNodeType.Text)
            {
                if (image != null)
                    UnityEngine.Object.DestroyImmediate(image);
                text = gameObject.GetComponent<Text>() ?? gameObject.AddComponent<Text>();
                if (text.font == null)
                    text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                text.text = option.text ?? "";
                text.fontSize = Mathf.Max(1, option.fontSize);
                text.color = option.textColor;
                text.alignment = option.textAlignment;
                text.raycastTarget = false;
                return;
            }

            var needsImage = option.type == PsdNodeType.Image || option.type == PsdNodeType.FlattenedImage || option.type == PsdNodeType.Button;
            if (!needsImage)
            {
                if (image != null)
                    UnityEngine.Object.DestroyImmediate(image);
                return;
            }

            image = gameObject.GetComponent<Image>() ?? gameObject.AddComponent<Image>();
            var groupButton = option.type == PsdNodeType.Button && layer.group;
            image.sprite = groupButton ? null : AssetDatabase.LoadAssetAtPath<Sprite>(spritePaths[layer.id]);
            if (!groupButton && image.sprite == null)
                throw new InvalidOperationException("图层图片未成功导入为 Sprite：" + layer.name);
            image.color = groupButton ? new Color(1f, 1f, 1f, 0f) : Color.white;
            image.type = !groupButton && option.sliced ? Image.Type.Sliced : Image.Type.Simple;
            image.raycastTarget = option.type == PsdNodeType.Button;
            image.preserveAspect = false;
            if (option.type == PsdNodeType.Button)
            {
                button = gameObject.GetComponent<Button>() ?? gameObject.AddComponent<Button>();
                button.targetGraphic = image;
            }
        }
    }
}
