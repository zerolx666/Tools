using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PsdToPrefab.Editor
{
    [Serializable]
    internal sealed class PsdDocument
    {
        public int version;
        public string name;
        public int width;
        public int height;
        public List<PsdLayer> nodes = new List<PsdLayer>();
    }

    [Serializable]
    internal sealed class PsdLayer
    {
        public string id;
        public string parentId;
        public string name;
        public int x;
        public int y;
        public int width;
        public int height;
        public string kind;
        public string text;
        public string asset;
        public bool visible;
        public bool group;
        public int depth;
        public string warning;
    }

    internal enum PsdNodeType
    {
        Container,
        Image,
        Button,
        Text,
        Ignore,
        FlattenedImage
    }

    internal enum PsdAnchor
    {
        Center,
        TopLeft,
        Top,
        TopRight,
        Left,
        Right,
        BottomLeft,
        Bottom,
        BottomRight,
        StretchHorizontal,
        StretchVertical,
        StretchBoth
    }

    [Serializable]
    internal sealed class PsdNodeOption
    {
        public string id;
        public PsdNodeType type;
        public PsdAnchor anchor;
        public string text;
        public int fontSize = 24;
        public Color textColor = Color.white;
        public TextAnchor textAlignment = TextAnchor.MiddleCenter;
        public bool sliced;
        public Vector4 spriteBorder;
    }

    [Serializable]
    internal sealed class PsdImportSettings
    {
        public string sourcePath;
        public List<PsdNodeOption> options = new List<PsdNodeOption>();
    }
}
