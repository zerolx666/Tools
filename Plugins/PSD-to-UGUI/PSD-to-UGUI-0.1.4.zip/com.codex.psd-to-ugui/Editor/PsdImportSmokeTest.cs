using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace PsdToPrefab.Editor
{
    public static class PsdImportSmokeTest
    {
        public static void Run()
        {
            RunPreviewChecks();
            Require(PsdImportWindow.SourceBrowseDirectory("", Application.dataPath) == Application.dataPath,
                "空 PSD 路径应从项目 Assets 目录打开文件选择窗口");
            Require(PsdImportWindow.SourceBrowseDirectory("\0", Application.dataPath) == Application.dataPath,
                "无效 PSD 路径应回退到项目 Assets 目录");
            var token = Guid.NewGuid().ToString("N");
            var outputRoot = "Assets/PsdToPrefabSmoke_" + token;
            var staging = Path.Combine(Path.GetTempPath(), "PsdToPrefabSmoke_" + token);
            try
            {
                Directory.CreateDirectory(Path.Combine(staging, "Images"));
                var texture = new Texture2D(10, 10, TextureFormat.RGBA32, false);
                for (var y = 0; y < 10; y++)
                    for (var x = 0; x < 10; x++)
                        texture.SetPixel(x, y, Color.red);
                texture.Apply();
                File.WriteAllBytes(Path.Combine(staging, "Images", "child.png"), texture.EncodeToPNG());
                UnityEngine.Object.DestroyImmediate(texture);

                var document = new PsdDocument
                {
                    version = 1,
                    name = "Panel",
                    width = 100,
                    height = 60,
                    nodes = new List<PsdLayer>
                    {
                        new PsdLayer { id = "group", parentId = "", name = "Panel group", x = 20, y = 10, width = 40, height = 30, group = true, visible = true },
                        new PsdLayer { id = "child", parentId = "group", name = "Icon", x = 25, y = 15, width = 10, height = 10, asset = "Images/child.png", visible = true }
                    }
                };
                var previewBounds = PsdImportWindow.LayerPreviewRect(new Rect(0, 0, 250, 150),
                    document, document.nodes[1]);
                Require(Mathf.Abs(previewBounds.x - 62.5f) < 0.01f &&
                        Mathf.Abs(previewBounds.y - 37.5f) < 0.01f &&
                        Mathf.Abs(previewBounds.width - 25f) < 0.01f &&
                        Mathf.Abs(previewBounds.height - 25f) < 0.01f,
                    "图层位置与预览图坐标不一致");
                var settings = new PsdImportSettings
                {
                    sourcePath = Path.Combine(staging, "sample.psd"),
                    options = new List<PsdNodeOption>
                    {
                        new PsdNodeOption { id = "group", type = PsdNodeType.Button, anchor = PsdAnchor.TopLeft },
                        new PsdNodeOption { id = "child", type = PsdNodeType.Image, anchor = PsdAnchor.Center }
                    }
                };

                var prefabPath = PsdPrefabBuilder.Build(document, settings, staging, outputRoot);
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                Require(prefab != null, "未生成预制体");
                var group = prefab.transform.Find("Panel group") as RectTransform;
                Require(group != null && group.GetComponent<UnityEngine.UI.Button>() != null, "未生成按钮图层组");
                Require(Vector2.Distance(group.anchoredPosition, new Vector2(40, -25)) < 0.01f, "图层组锚点位置错误");
                Require(group.Find("Icon") != null, "子图层未放入图层组");
                var spritePath = PsdPrefabBuilder.OutputFolder(outputRoot, document.name) + "/Images/child.png";
                var importer = AssetImporter.GetAtPath(spritePath) as TextureImporter;
                Require(importer != null && importer.textureType == TextureImporterType.Sprite &&
                        importer.spriteImportMode == SpriteImportMode.Single,
                    "首次生成应将图层图片设为 Single Sprite");
                Require(group.Find("Icon").GetComponent<UnityEngine.UI.Image>().sprite != null,
                    "首次生成的 Image 未绑定 Sprite");
                var spriteGuid = AssetDatabase.AssetPathToGUID(spritePath);

                var contents = PrefabUtility.LoadPrefabContents(prefabPath);
                try
                {
                    contents.transform.Find("Panel group/Icon").gameObject.AddComponent<CanvasGroup>();
                    PrefabUtility.SaveAsPrefabAsset(contents, prefabPath);
                }
                finally
                {
                    PrefabUtility.UnloadPrefabContents(contents);
                }

                // Reproduce the failure even when every other importer setting is already correct.
                importer = AssetImporter.GetAtPath(spritePath) as TextureImporter;
                importer.spriteImportMode = SpriteImportMode.Multiple;
                importer.SaveAndReimport();
                Require(AssetDatabase.LoadAssetAtPath<Sprite>(spritePath) == null,
                    "回归测试需要一个没有切片的 Multiple 图片");

                PsdPrefabBuilder.Build(document, settings, staging, outputRoot);
                prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                importer = AssetImporter.GetAtPath(spritePath) as TextureImporter;
                Require(importer != null && importer.spriteImportMode == SpriteImportMode.Single,
                    "再次生成未自动纠正 Multiple 模式");
                Require(prefab.transform.Find("Panel group/Icon").GetComponent<UnityEngine.UI.Image>().sprite != null,
                    "纠正导入模式后 Image 未绑定 Sprite");
                Require(AssetDatabase.AssetPathToGUID(spritePath) == spriteGuid,
                    "纠正导入模式不应改变图片 GUID");
                Require(prefab.transform.Find("Panel group/Icon").GetComponent<CanvasGroup>() != null,
                    "重新导入后自定义组件丢失");

                settings.options[1].type = PsdNodeType.Ignore;
                PsdPrefabBuilder.Build(document, settings, staging, outputRoot);
                prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                var obsolete = prefab.transform.Find("Panel group/Icon").GetComponent<PsdGeneratedNode>();
                Require(obsolete.obsolete && !obsolete.gameObject.activeSelf, "忽略的图层应被禁用，不应删除");
                Debug.Log("PSD 转 UGUI 烟雾测试通过");
            }
            finally
            {
                AssetDatabase.DeleteAsset(outputRoot);
                if (Directory.Exists(staging))
                    Directory.Delete(staging, true);
            }
        }

        public static void RunPreviewChecks()
        {
            var source = new PsdDocument { width = 3556, height = 2000 };
            var group = new PsdLayer { id = "group", name = "Design" };
            var layer = new PsdLayer { id = "child", parentId = "group", name = "Shape",
                x = 3116, y = 150, width = 62, height = 55 };
            source.nodes.Add(group);
            source.nodes.Add(layer);
            Require(PsdImportWindow.LayerHierarchyPath(source, layer) == "Design / Shape", "分组路径错误");
            group.parentId = layer.id;
            Require(PsdImportWindow.LayerHierarchyPath(source, layer) == "Design / Shape", "分组循环未被安全终止");
            group.parentId = null;
            layer.parentId = "missing";
            Require(PsdImportWindow.LayerHierarchyPath(source, layer) == "Shape", "缺失父级应仍显示图层名称");

            var viewport = new Vector2(800, 500);
            var center = new Vector2(1778, 1000);
            var anchor = new Vector2(710, 80);
            var nextCenter = PsdPreviewView.ZoomCenter(center, anchor, viewport, 0.25f, 2f);
            var before = center + (anchor - viewport * 0.5f) / 0.25f;
            var after = nextCenter + (anchor - viewport * 0.5f) / 2f;
            Require(Vector2.Distance(before, after) < 0.001f, "滚轮缩放没有固定鼠标下的图片坐标");

            var layerCenter = new Vector2(layer.x + layer.width * 0.5f, layer.y + layer.height * 0.5f);
            var image = PsdPreviewView.ImageRect(viewport, new Vector2(source.width, source.height), layerCenter, 3f);
            var bounds = PsdImportWindow.LayerPreviewRect(image, source, layer);
            Require(Vector2.Distance(bounds.center, viewport * 0.5f) < 0.01f &&
                    Mathf.Abs(bounds.width - 186f) < 0.01f && Mathf.Abs(bounds.height - 165f) < 0.01f,
                "缩放和平移后的图层定位框不匹配");
            var zoom = PsdPreviewView.FitZoom(viewport, new Vector2(source.width, source.height));
            Require(source.width * zoom <= viewport.x && source.height * zoom <= viewport.y, "适应窗口裁掉了整图");
            Require(PsdPreviewView.FitZoom(Vector2.one, Vector2.zero) > 0f, "极小窗口和空边界应安全处理");
        }

        private static void Require(bool condition, string message)
        {
            if (!condition)
                throw new InvalidOperationException(message);
        }
    }
}
